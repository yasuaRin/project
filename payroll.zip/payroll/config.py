# config.py
DB_CONFIG = {
    "dbname": "payroll_db",
    "user": "postgres",
    "password": "admin",
    "host": "localhost",
    "port": 5432  # <-- now an integer
}