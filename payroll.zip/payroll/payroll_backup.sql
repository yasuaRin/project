--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

-- Started on 2025-05-19 09:48:15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 25382)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    first_name text,
    last_name text,
    gender text,
    start_date date,
    years integer,
    department text,
    country text,
    monthly_salary numeric(10,2),
    annual_salary numeric(10,2),
    job_rate numeric(5,2),
    sick_leave integer,
    unpaid_leaves integer,
    overtime_hours numeric(5,2)
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 25354)
-- Name: tax_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_rates (
    id integer NOT NULL,
    min_salary numeric(10,2) NOT NULL,
    max_salary numeric(10,2) NOT NULL,
    tax_percentage numeric(5,2) NOT NULL
);


ALTER TABLE public.tax_rates OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 25353)
-- Name: tax_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tax_rates_id_seq OWNER TO postgres;

--
-- TOC entry 4918 (class 0 OID 0)
-- Dependencies: 217
-- Name: tax_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_rates_id_seq OWNED BY public.tax_rates.id;


--
-- TOC entry 221 (class 1259 OID 25390)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'admin'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 25389)
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO postgres;

--
-- TOC entry 4919 (class 0 OID 0)
-- Dependencies: 220
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- TOC entry 4751 (class 2604 OID 25357)
-- Name: tax_rates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_rates ALTER COLUMN id SET DEFAULT nextval('public.tax_rates_id_seq'::regclass);


--
-- TOC entry 4752 (class 2604 OID 25393)
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- TOC entry 4910 (class 0 OID 25382)
-- Dependencies: 219
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.employees VALUES (6, 'Muhamad', 'Zueitr', 'Male', '2016-02-02', 9, 'Product Development', 'Saudi Arabia', 2332.00, 27984.00, 3.00, 3, 0, 8.00);
INSERT INTO public.employees VALUES (7, 'Iin', 'Alhalaliu', 'Female', '2020-05-08', 5, 'Sales', 'United Arab Emirates', 1959.00, 23508.00, 3.00, 6, 0, 116.00);
INSERT INTO public.employees VALUES (8, 'Muhamad', 'Alaya', 'Male', '2018-02-10', 7, 'Account Management', 'Egypt', 3394.00, 40728.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (9, 'Susin', 'Almilat', 'Female', '2018-03-11', 7, 'Green Building', 'Egypt', 1479.00, 17748.00, 4.50, 0, 0, 105.00);
INSERT INTO public.employees VALUES (10, 'Muhamad', 'Alrifaei', 'Male', '2020-01-03', 5, 'Account Management', 'Egypt', 1186.00, 14232.00, 4.50, 1, 0, 153.00);
INSERT INTO public.employees VALUES (11, 'Muhamad', 'Alqadah', 'Male', '2018-01-16', 7, 'Manufacturing', 'Syria', 1485.00, 17820.00, 2.00, 5, 0, 12.00);
INSERT INTO public.employees VALUES (12, 'Muhamad', 'Iad', 'Male', '2018-07-19', 6, 'IT', 'Egypt', 2016.00, 24192.00, 1.00, 2, 0, 70.00);
INSERT INTO public.employees VALUES (13, 'Razaan', 'Nasif', 'Female', '2018-11-11', 6, 'Facilities/Engineering', 'Egypt', 1999.00, 23988.00, 5.00, 6, 0, 85.00);
INSERT INTO public.employees VALUES (14, 'Iilian', 'Dbs', 'Female', '2016-03-01', 9, 'Facilities/Engineering', 'United Arab Emirates', 3404.00, 40848.00, 5.00, 1, 0, 8.00);
INSERT INTO public.employees VALUES (15, 'Bayan', 'Qdw', 'Female', '2018-12-04', 6, 'Marketing', 'Egypt', 889.00, 10668.00, 3.00, 1, 1, 8.00);
INSERT INTO public.employees VALUES (16, 'Alaa', 'Muhamad', 'Male', '2019-10-07', 5, 'Sales', 'Egypt', 930.00, 11160.00, 3.00, 0, 0, 77.00);
INSERT INTO public.employees VALUES (17, 'Sandra', 'Aljurmqaniu', 'Female', '2016-05-27', 8, 'Account Management', 'Saudi Arabia', 3149.00, 37788.00, 4.50, 0, 0, 93.00);
INSERT INTO public.employees VALUES (18, 'Farahad', 'Husayn', 'Male', '2018-05-12', 7, 'Quality Control', 'United Arab Emirates', 1295.00, 15540.00, 3.00, 4, 0, 153.00);
INSERT INTO public.employees VALUES (19, 'Ahed', 'Salim', 'Female', '2018-04-24', 7, 'Quality Control', 'United Arab Emirates', 2162.00, 25944.00, 3.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (20, 'Ayham', 'Tutwnji', 'Male', '2019-10-02', 5, 'Product Development', 'United Arab Emirates', 2180.00, 26160.00, 2.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (21, 'Samir', 'Alsafdi', 'Male', '2020-12-03', 4, 'Account Management', 'Egypt', 1475.00, 17700.00, 5.00, 0, 0, 98.00);
INSERT INTO public.employees VALUES (22, 'Bilal', 'Jalal', 'Male', '2019-01-08', 6, 'Manufacturing Admin', 'Egypt', 1290.00, 15480.00, 3.00, 4, 0, 109.00);
INSERT INTO public.employees VALUES (23, 'Riad', 'Sahalul', 'Male', '2019-11-14', 5, 'Training', 'Saudi Arabia', 1764.00, 21168.00, 3.00, 0, 0, 111.00);
INSERT INTO public.employees VALUES (24, 'Ahmad', 'Ahmad', 'Male', '2019-10-17', 5, 'Quality Assurance', 'Saudi Arabia', 2682.00, 32184.00, 4.50, 1, 0, 32.00);
INSERT INTO public.employees VALUES (25, 'Muhamad', 'Altarah', 'Male', '2020-12-13', 4, 'IT', 'Egypt', 3044.00, 36528.00, 3.00, 6, 0, 94.00);
INSERT INTO public.employees VALUES (26, 'Lwna', 'Abu', 'Female', '2020-08-02', 4, 'Product Development', 'Egypt', 890.00, 10680.00, 4.50, 0, 0, 13.00);
INSERT INTO public.employees VALUES (27, 'Jalal', 'Almuluhi', 'Male', '2018-12-03', 6, 'Quality Control', 'Egypt', 2207.00, 26484.00, 5.00, 0, 0, 70.00);
INSERT INTO public.employees VALUES (28, 'Rana', 'Mius', 'Female', '2019-03-06', 6, 'Manufacturing', 'Saudi Arabia', 2136.00, 25632.00, 4.50, 1, 0, 9.00);
INSERT INTO public.employees VALUES (29, 'Lina', 'Aljabaan', 'Female', '2019-12-16', 5, 'Quality Control', 'Egypt', 1161.00, 13932.00, 5.00, 0, 1, 97.00);
INSERT INTO public.employees VALUES (30, 'Rami', 'Shanan', 'Male', '2019-08-13', 5, 'Professional Training Group', 'United Arab Emirates', 830.00, 9960.00, 5.00, 0, 0, 71.00);
INSERT INTO public.employees VALUES (31, 'Eala', 'Alhaj', 'Female', '2020-06-09', 4, 'Quality Assurance', 'Saudi Arabia', 2977.00, 35724.00, 5.00, 0, 0, 100.00);
INSERT INTO public.employees VALUES (32, 'Ghalib', 'Zakianiin', 'Male', '2019-05-19', 5, 'Environmental Compliance', 'Syria', 3151.00, 37812.00, 3.00, 0, 5, 48.00);
INSERT INTO public.employees VALUES (33, 'Muhamad', 'Eurul', 'Male', '2017-05-03', 8, 'Quality Assurance', 'Egypt', 1551.00, 18612.00, 1.00, 0, 0, 148.00);
INSERT INTO public.employees VALUES (34, 'Eizat', 'Ghanim', 'Male', '2017-06-21', 7, 'Product Development', 'United Arab Emirates', 2099.00, 25188.00, 1.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (35, 'Ahmad', 'Swyd', 'Male', '2017-02-01', 8, 'Sales', 'Egypt', 808.00, 9696.00, 4.50, 1, 0, 7.00);
INSERT INTO public.employees VALUES (36, 'Muhamad', 'Aleass', 'Male', '2019-09-23', 5, 'Manufacturing', 'Saudi Arabia', 984.00, 11808.00, 4.50, 6, 0, 37.00);
INSERT INTO public.employees VALUES (37, 'Rima', 'AlAsfar', 'Female', '2016-01-27', 9, 'Quality Assurance', 'Egypt', 1011.00, 12132.00, 5.00, 0, 3, 5.00);
INSERT INTO public.employees VALUES (38, 'Zayn', 'Aleabdyn Zaetar', 'Female', '2020-11-29', 4, 'Quality Control', 'United Arab Emirates', 2026.00, 24312.00, 5.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (39, 'Hazim', 'Alshshatim', 'Male', '2018-06-17', 6, 'Quality Control', 'Egypt', 2801.00, 33612.00, 3.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (40, 'Dia', 'Alshahf', 'Male', '2019-09-14', 5, 'Marketing', 'United Arab Emirates', 3208.00, 38496.00, 3.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (41, 'Ayham', 'Almusaa', 'Male', '2019-04-26', 6, 'Manufacturing', 'Saudi Arabia', 2129.00, 25548.00, 4.50, 0, 0, 26.00);
INSERT INTO public.employees VALUES (42, 'Abd Allatif', 'Mabrukh', 'Male', '2020-12-10', 4, 'Facilities/Engineering', 'Egypt', 3344.00, 40128.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (43, 'Salim', 'Abumaeun', 'Male', '2017-06-30', 7, 'Account Management', 'United Arab Emirates', 2836.00, 34032.00, 5.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (44, 'Rafat', 'Hamza', 'Male', '2020-05-03', 5, 'Quality Control', 'Saudi Arabia', 1960.00, 23520.00, 3.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (45, 'Ahmad', 'Laylana', 'Male', '2016-11-27', 8, 'Facilities/Engineering', 'Egypt', 1478.00, 17736.00, 4.50, 5, 6, 7.00);
INSERT INTO public.employees VALUES (46, 'Lobnaa', 'Khalifih', 'Female', '2019-12-18', 5, 'Marketing', 'United Arab Emirates', 1981.00, 23772.00, 2.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (47, 'Sami', 'Alkhujih', 'Male', '2019-04-17', 6, 'Creative', 'United Arab Emirates', 2064.00, 24768.00, 2.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (48, 'Salam', 'Alealbi', 'Female', '2016-03-09', 9, 'Manufacturing', 'Egypt', 1045.00, 12540.00, 5.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (49, 'Rim', 'Almusaa', 'Female', '2020-05-06', 5, 'Manufacturing', 'Egypt', 2022.00, 24264.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (50, 'Ghada', 'Aleasimii', 'Female', '2019-10-21', 5, 'Quality Assurance', 'Egypt', 2383.00, 28596.00, 5.00, 0, 4, 1.00);
INSERT INTO public.employees VALUES (51, 'Abd Alwahhab', 'Muhamad', 'Male', '2018-10-30', 6, 'Manufacturing', 'Egypt', 1563.00, 18756.00, 3.00, 3, 0, 1.00);
INSERT INTO public.employees VALUES (52, 'Ayman', 'Eubayd', 'Male', '2019-08-22', 5, 'Sales', 'Saudi Arabia', 919.00, 11028.00, 2.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (53, 'Faras', 'Karim', 'Male', '2020-10-23', 4, 'Quality Assurance', 'Egypt', 988.00, 11856.00, 5.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (54, 'Shadi', 'Salayk', 'Male', '2019-02-02', 6, 'Quality Assurance', 'United Arab Emirates', 2631.00, 31572.00, 3.00, 3, 6, 10.00);
INSERT INTO public.employees VALUES (55, 'Eubay', 'Alttahir', 'Male', '2016-09-16', 8, 'Quality Control', 'Egypt', 2368.00, 28416.00, 3.00, 6, 0, 5.00);
INSERT INTO public.employees VALUES (56, 'Abd Alhadi', 'Alzzahir', 'Male', '2018-03-14', 7, 'Sales', 'Egypt', 2679.00, 32148.00, 3.00, 3, 0, 85.00);
INSERT INTO public.employees VALUES (57, 'Majdulin', 'Ashbrh', 'Female', '2019-03-16', 6, 'Account Management', 'Egypt', 2423.00, 29076.00, 3.00, 5, 0, 10.00);
INSERT INTO public.employees VALUES (58, 'Aylyn', 'Dahadal', 'Female', '2020-01-19', 5, 'Quality Assurance', 'Egypt', 2115.00, 25380.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (59, 'Tala', 'Tuish', 'Female', '2019-04-21', 6, 'Product Development', 'United Arab Emirates', 2969.00, 35628.00, 1.00, 0, 0, 11.00);
INSERT INTO public.employees VALUES (60, 'Muhamad', 'Qarh', 'Male', '2019-07-19', 5, 'Training', 'Egypt', 2467.00, 29604.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (61, 'Eala', 'Almisri', 'Female', '2019-04-27', 6, 'Facilities/Engineering', 'Egypt', 3244.00, 38928.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (62, 'Muhamad', 'Alzaybq', 'Male', '2018-12-05', 6, 'Research/Development', 'Egypt', 2132.00, 25584.00, 3.00, 5, 0, 2.00);
INSERT INTO public.employees VALUES (63, 'Muhamad', 'Asamy', 'Male', '2017-03-25', 8, 'Manufacturing', 'United Arab Emirates', 994.00, 11928.00, 3.00, 6, 4, 0.00);
INSERT INTO public.employees VALUES (64, 'Ahmad', 'Alealbi', 'Male', '2016-01-20', 9, 'IT', 'Egypt', 2304.00, 27648.00, 5.00, 5, 0, 2.00);
INSERT INTO public.employees VALUES (65, 'Ibrahim', 'Almasri', 'Male', '2018-06-29', 6, 'Quality Assurance', 'Egypt', 1207.00, 14484.00, 2.00, 0, 0, 50.00);
INSERT INTO public.employees VALUES (2, 'Omar', 'Hishan', 'Male', '2020-05-21', 4, 'Quality Control', 'Saudi Arabia', 3247.00, 38964.00, 1.00, 0, 6, 198.00);
INSERT INTO public.employees VALUES (3, 'Ailya', 'Sharafy', 'Female', '2017-09-28', 7, 'Major Mfg Projects', 'Saudi Arabia', 2506.00, 30072.00, 2.00, 0, 3, 192.00);
INSERT INTO public.employees VALUES (4, 'Lwie', 'Qbany', 'Male', '2018-08-14', 6, 'Manufacturing', 'United Arab Emirates', 1828.00, 21936.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (5, 'Ahmad', 'Bikri', 'Male', '2020-03-11', 5, 'Manufacturing', 'Egypt', 970.00, 11640.00, 5.00, 0, 5, 121.00);
INSERT INTO public.employees VALUES (66, 'Hamdah', 'Alkhalifa', 'Male', '2019-09-07', 5, 'Manufacturing', 'Syria', 802.00, 9624.00, 4.50, 2, 0, 3.00);
INSERT INTO public.employees VALUES (67, 'Muhamad', 'Jawish', 'Male', '2019-11-25', 5, 'Marketing', 'United Arab Emirates', 2065.00, 24780.00, 3.00, 4, 3, 4.00);
INSERT INTO public.employees VALUES (68, 'Muwmin', 'Almudhin', 'Male', '2020-06-28', 4, 'IT', 'Egypt', 2882.00, 34584.00, 5.00, 0, 4, 0.00);
INSERT INTO public.employees VALUES (69, 'Ahmad', 'Zayd', 'Male', '2018-06-17', 6, 'Account Management', 'Egypt', 2042.00, 24504.00, 5.00, 0, 3, 64.00);
INSERT INTO public.employees VALUES (70, 'Layzaan', 'Nabulsi', 'Male', '2019-12-03', 5, 'Facilities/Engineering', 'Saudi Arabia', 2017.00, 24204.00, 3.00, 6, 0, 8.00);
INSERT INTO public.employees VALUES (71, 'Sarih', 'Eammar', 'Male', '2018-07-03', 6, 'Quality Assurance', 'Syria', 3215.00, 38580.00, 2.00, 5, 0, 2.00);
INSERT INTO public.employees VALUES (72, 'Karam', 'Hutayniun', 'Male', '2016-11-17', 8, 'Manufacturing', 'United Arab Emirates', 2957.00, 35484.00, 5.00, 1, 0, 10.00);
INSERT INTO public.employees VALUES (73, 'Shahad', 'Shanan', 'Female', '2019-10-02', 5, 'Product Development', 'Syria', 891.00, 10692.00, 3.00, 0, 2, 6.00);
INSERT INTO public.employees VALUES (74, 'Salah', 'Ramadan', 'Male', '2018-08-27', 6, 'Environmental Health/Safety', 'United Arab Emirates', 1971.00, 23652.00, 4.50, 5, 1, 0.00);
INSERT INTO public.employees VALUES (75, 'Sami', 'Alkhayrat', 'Male', '2020-11-14', 4, 'Facilities/Engineering', 'United Arab Emirates', 2317.00, 27804.00, 3.00, 6, 1, 10.00);
INSERT INTO public.employees VALUES (76, 'Khalid', 'Snan', 'Male', '2019-11-28', 5, 'Manufacturing', 'Egypt', 1657.00, 19884.00, 3.00, 0, 0, 12.00);
INSERT INTO public.employees VALUES (77, 'Salam', 'Alkhatib', 'Male', '2018-04-20', 7, 'Manufacturing', 'Egypt', 3053.00, 36636.00, 3.00, 0, 3, 6.00);
INSERT INTO public.employees VALUES (78, 'Darar', 'Alshiyraziu', 'Male', '2020-01-10', 5, 'Manufacturing', 'United Arab Emirates', 1887.00, 22644.00, 1.00, 6, 0, 4.00);
INSERT INTO public.employees VALUES (79, 'Mazin', 'Yusif', 'Male', '2018-11-07', 6, 'Manufacturing', 'United Arab Emirates', 1457.00, 17484.00, 4.50, 0, 0, 9.00);
INSERT INTO public.employees VALUES (80, 'Rasha', 'Naeim', 'Female', '2019-05-06', 6, 'Quality Control', 'Egypt', 2581.00, 30972.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (81, 'Eamra', 'Alshueranii', 'Female', '2016-08-27', 8, 'IT', 'United Arab Emirates', 901.00, 10812.00, 5.00, 0, 2, 10.00);
INSERT INTO public.employees VALUES (82, 'Amira', 'Akrym', 'Female', '2016-06-23', 8, 'Account Management', 'United Arab Emirates', 898.00, 10776.00, 4.50, 3, 0, 11.00);
INSERT INTO public.employees VALUES (83, 'Muhamad', 'Hamzat', 'Male', '2020-08-26', 4, 'Account Management', 'Egypt', 2878.00, 34536.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (84, 'Muhamad', 'Khayr', 'Male', '2018-01-16', 7, 'Environmental Compliance', 'Egypt', 2539.00, 30468.00, 3.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (85, 'Abd Almalik', 'Nazal', 'Male', '2018-07-05', 6, 'Quality Control', 'Egypt', 2533.00, 30396.00, 5.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (86, 'Rabya', 'Kiwan', 'Female', '2019-01-16', 6, 'Training', 'Egypt', 885.00, 10620.00, 3.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (87, 'Muhamad', 'Khayr', 'Male', '2019-06-19', 5, 'Facilities/Engineering', 'United Arab Emirates', 1166.00, 13992.00, 5.00, 0, 4, 5.00);
INSERT INTO public.employees VALUES (88, 'Samah', 'Almaydanii', 'Female', '2017-10-01', 7, 'Account Management', 'United Arab Emirates', 2022.00, 24264.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (89, 'Ali', 'Watar', 'Male', '2020-01-26', 5, 'Training', 'Egypt', 1752.00, 21024.00, 2.00, 5, 4, 76.00);
INSERT INTO public.employees VALUES (90, 'Darin', 'Ghunum', 'Female', '2019-07-20', 5, 'IT', 'Egypt', 3157.00, 37884.00, 1.00, 6, 1, 4.00);
INSERT INTO public.employees VALUES (91, 'Faras', 'Alhamal', 'Male', '2020-07-27', 4, 'Quality Control', 'Egypt', 3211.00, 38532.00, 5.00, 6, 1, 9.00);
INSERT INTO public.employees VALUES (92, 'Amal', 'Asamy', 'Female', '2018-10-11', 6, 'Quality Assurance', 'Egypt', 1062.00, 12744.00, 3.00, 1, 0, 7.00);
INSERT INTO public.employees VALUES (93, 'Razan', 'AlAhmad', 'Female', '2019-07-11', 5, 'Facilities/Engineering', 'Egypt', 1406.00, 16872.00, 4.50, 4, 0, 46.00);
INSERT INTO public.employees VALUES (94, 'Muhamad', 'Kharasah', 'Male', '2019-08-17', 5, 'Environmental Compliance', 'United Arab Emirates', 3084.00, 37008.00, 3.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (95, 'Tariq', 'Bryghl', 'Male', '2020-11-04', 4, 'Marketing', 'Egypt', 1815.00, 21780.00, 4.50, 1, 0, 9.00);
INSERT INTO public.employees VALUES (96, 'Muhamad', 'Husayn', 'Male', '2017-07-21', 7, 'IT', 'United Arab Emirates', 1861.00, 22332.00, 3.00, 0, 5, 9.00);
INSERT INTO public.employees VALUES (97, 'Fadi', 'Aleid', 'Male', '2018-04-10', 7, 'Manufacturing', 'United Arab Emirates', 3088.00, 37056.00, 5.00, 3, 0, 10.00);
INSERT INTO public.employees VALUES (98, 'Tariq', 'Abuzahir', 'Male', '2017-05-03', 8, 'Human Resources', 'Syria', 3071.00, 36852.00, 5.00, 6, 0, 2.00);
INSERT INTO public.employees VALUES (99, 'Mazin', 'Eubayd', 'Male', '2018-11-29', 6, 'Manufacturing', 'United Arab Emirates', 3298.00, 39576.00, 3.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (100, 'Lina', 'Aljabr', 'Female', '2018-08-27', 6, 'Product Development', 'Saudi Arabia', 828.00, 9936.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (101, 'Muhamad', 'Ayman', 'Male', '2019-11-17', 5, 'Manufacturing', 'Egypt', 2404.00, 28848.00, 4.50, 0, 0, 99.00);
INSERT INTO public.employees VALUES (102, 'Ayman', 'Muhamad', 'Male', '2019-10-02', 5, 'Marketing', 'Egypt', 3410.00, 40920.00, 3.00, 2, 0, 8.00);
INSERT INTO public.employees VALUES (103, 'Ahmad', 'Abu Eadlh', 'Male', '2019-11-24', 5, 'Product Development', 'United Arab Emirates', 1817.00, 21804.00, 5.00, 1, 0, 1.00);
INSERT INTO public.employees VALUES (104, 'Rami', 'Abu Adhan', 'Male', '2020-02-06', 5, 'Manufacturing', 'Syria', 2923.00, 35076.00, 2.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (105, 'Muhamad', 'Hamzat', 'Male', '2018-10-24', 6, 'Professional Training Group', 'Egypt', 3138.00, 37656.00, 5.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (106, 'Ehab', 'Alkhibaz', 'Male', '2020-05-28', 4, 'Account Management', 'Egypt', 3139.00, 37668.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (107, 'Ibrahim', 'Nabulsi', 'Male', '2016-05-17', 8, 'Training', 'United Arab Emirates', 3263.00, 39156.00, 3.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (108, 'Ranya', 'Salah Aldiyn', 'Female', '2019-01-22', 6, 'Quality Control', 'United Arab Emirates', 1258.00, 15096.00, 5.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (109, 'Juri', 'Zaytun', 'Female', '2020-09-11', 4, 'Marketing', 'Egypt', 2527.00, 30324.00, 3.00, 3, 0, 16.00);
INSERT INTO public.employees VALUES (110, 'Sahar', 'Almuhamad', 'Female', '2018-09-19', 6, 'Marketing', 'Egypt', 3017.00, 36204.00, 4.50, 0, 4, 4.00);
INSERT INTO public.employees VALUES (111, 'Mari', 'Ayly', 'Female', '2016-04-20', 9, 'Account Management', 'Saudi Arabia', 1639.00, 19668.00, 5.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (112, 'Ali', 'Alhuri', 'Male', '2019-10-04', 5, 'IT', 'Egypt', 1867.00, 22404.00, 3.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (113, 'Dania', 'Almala', 'Female', '2016-10-16', 8, 'Quality Assurance', 'United Arab Emirates', 2314.00, 27768.00, 2.00, 0, 3, 5.00);
INSERT INTO public.employees VALUES (114, 'Rym', 'Alsydawi', 'Female', '2017-02-04', 8, 'Quality Control', 'Saudi Arabia', 2679.00, 32148.00, 5.00, 6, 0, 1.00);
INSERT INTO public.employees VALUES (115, 'Mahir', 'Alshear', 'Male', '2019-06-02', 5, 'Quality Control', 'Egypt', 3166.00, 37992.00, 4.50, 5, 0, 4.00);
INSERT INTO public.employees VALUES (116, 'Ibrahim', 'Alhamid', 'Male', '2019-03-03', 6, 'Manufacturing', 'United Arab Emirates', 2429.00, 29148.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (117, 'Muhamad', 'Alkhayr', 'Male', '2019-10-06', 5, 'Manufacturing', 'United Arab Emirates', 1865.00, 22380.00, 4.50, 0, 0, 4.00);
INSERT INTO public.employees VALUES (118, 'Muhamad', 'Bashshar', 'Male', '2018-02-15', 7, 'Account Management', 'United Arab Emirates', 868.00, 10416.00, 4.50, 2, 0, 2.00);
INSERT INTO public.employees VALUES (119, 'Muhamad', 'Jhad', 'Male', '2019-04-03', 6, 'Manufacturing', 'Egypt', 3411.00, 40932.00, 5.00, 4, 0, 2.00);
INSERT INTO public.employees VALUES (120, 'Limays', 'Ghrz', 'Female', '2016-11-13', 8, 'Marketing', 'Syria', 3324.00, 39888.00, 3.00, 5, 0, 7.00);
INSERT INTO public.employees VALUES (121, 'Zaydun', 'Jabir', 'Male', '2019-10-24', 5, 'Manufacturing', 'United Arab Emirates', 2715.00, 32580.00, 1.00, 0, 3, 3.00);
INSERT INTO public.employees VALUES (122, 'Fatima', 'Zaetar', 'Female', '2019-07-28', 5, 'Quality Assurance', 'United Arab Emirates', 2664.00, 31968.00, 4.50, 1, 0, 9.00);
INSERT INTO public.employees VALUES (123, 'Tariq', 'Shakir', 'Male', '2020-10-30', 4, 'Quality Control', 'Saudi Arabia', 1801.00, 21612.00, 5.00, 0, 0, 82.00);
INSERT INTO public.employees VALUES (124, 'Ruyda', 'Alhamadii', 'Female', '2018-01-25', 7, 'Manufacturing', 'United Arab Emirates', 1452.00, 17424.00, 3.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (125, 'Anwar', 'Almaseud', 'Male', '2017-06-28', 7, 'Quality Control', 'United Arab Emirates', 2358.00, 28296.00, 3.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (126, 'Fayaruz', 'Sabih', 'Female', '2019-08-11', 5, 'Manufacturing', 'Egypt', 784.00, 9408.00, 3.00, 2, 3, 9.00);
INSERT INTO public.employees VALUES (127, 'Jwny', 'Alrashid', 'Male', '2017-07-27', 7, 'Manufacturing', 'Egypt', 1423.00, 17076.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (128, 'Karam', 'Kiali', 'Male', '2018-07-28', 6, 'Human Resources', 'United Arab Emirates', 2174.00, 26088.00, 2.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (129, 'Jamal', 'Alhalib', 'Male', '2020-07-18', 4, 'Marketing', 'Egypt', 2182.00, 26184.00, 4.50, 6, 0, 74.00);
INSERT INTO public.employees VALUES (130, 'Suzan', 'Alsawis', 'Female', '2019-07-29', 5, 'Quality Control', 'Egypt', 2437.00, 29244.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (131, 'Alaa', 'Efan', 'Female', '2019-09-18', 5, 'Quality Control', 'Egypt', 926.00, 11112.00, 2.00, 3, 0, 1.00);
INSERT INTO public.employees VALUES (132, 'Jihad', 'Aldarawasha', 'Male', '2017-01-30', 8, 'Marketing', 'United Arab Emirates', 1506.00, 18072.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (133, 'Muhamad', 'Khalid', 'Male', '2018-01-03', 7, 'IT', 'Saudi Arabia', 3159.00, 37908.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (134, 'Haithim', 'Hujah', 'Male', '2017-09-04', 7, 'Quality Assurance', 'Syria', 1117.00, 13404.00, 1.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (135, 'Duhana', 'Alakhris', 'Female', '2018-06-14', 6, 'Quality Control', 'Syria', 2379.00, 28548.00, 4.50, 0, 0, 7.00);
INSERT INTO public.employees VALUES (136, 'Eazalidin', 'Almala', 'Male', '2019-11-28', 5, 'Manufacturing', 'Egypt', 2372.00, 28464.00, 5.00, 4, 1, 6.00);
INSERT INTO public.employees VALUES (137, 'Habib', 'Klizli', 'Male', '2020-02-09', 5, 'Quality Assurance', 'Egypt', 2908.00, 34896.00, 3.00, 0, 0, 12.00);
INSERT INTO public.employees VALUES (138, 'Rasha', 'Bajubuj', 'Female', '2020-05-12', 5, 'Environmental Compliance', 'Egypt', 2019.00, 24228.00, 3.00, 5, 2, 15.00);
INSERT INTO public.employees VALUES (139, 'Mahir', 'Albaghdadi', 'Male', '2018-05-29', 6, 'Manufacturing', 'Egypt', 877.00, 10524.00, 1.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (140, 'Alaa', 'Almunzilijiu', 'Male', '2019-03-22', 6, 'Marketing', 'Egypt', 1043.00, 12516.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (141, 'Labanaa', 'Qaziyha', 'Female', '2019-08-21', 5, 'IT', 'United Arab Emirates', 3258.00, 39096.00, 3.00, 3, 0, 0.00);
INSERT INTO public.employees VALUES (142, 'Fatnh', 'Abu', 'Female', '2020-11-30', 4, 'Quality Assurance', 'Saudi Arabia', 976.00, 11712.00, 5.00, 5, 0, 2.00);
INSERT INTO public.employees VALUES (143, 'Iilyas', 'Dahadal', 'Female', '2019-04-16', 6, 'Account Management', 'Egypt', 3096.00, 37152.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (144, 'Rim', 'Huaydi', 'Female', '2019-03-27', 6, 'Training', 'Egypt', 1985.00, 23820.00, 3.00, 6, 2, 6.00);
INSERT INTO public.employees VALUES (145, 'Ahmad', 'Muhamad', 'Male', '2020-01-20', 5, 'Product Development', 'United Arab Emirates', 2371.00, 28452.00, 5.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (146, 'Abd Alruhmin', 'Almahrus', 'Male', '2019-02-24', 6, 'Quality Assurance', 'Egypt', 2562.00, 30744.00, 2.00, 4, 0, 3.00);
INSERT INTO public.employees VALUES (147, 'Biaism', 'Tyzry', 'Female', '2020-08-28', 4, 'Quality Control', 'Syria', 1254.00, 15048.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (148, 'Omar', 'Milatu', 'Male', '2018-03-14', 7, 'Manufacturing', 'Syria', 793.00, 9516.00, 5.00, 6, 0, 2.00);
INSERT INTO public.employees VALUES (149, 'Alyida', 'Nieamah', 'Female', '2017-09-29', 7, 'Creative', 'Egypt', 2416.00, 28992.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (150, 'Kamal', 'Hajl', 'Male', '2017-02-07', 8, 'Facilities/Engineering', 'Syria', 822.00, 9864.00, 5.00, 6, 0, 1.00);
INSERT INTO public.employees VALUES (151, 'Amjad', 'Naghnagh', 'Male', '2020-10-14', 4, 'Manufacturing', 'Egypt', 1442.00, 17304.00, 5.00, 2, 1, 23.00);
INSERT INTO public.employees VALUES (152, 'Iin', 'Qisi', 'Female', '2019-11-11', 5, 'IT', 'Egypt', 887.00, 10644.00, 4.50, 0, 0, 54.00);
INSERT INTO public.employees VALUES (153, 'Basmah', 'Alhabis', 'Female', '2017-02-26', 8, 'Manufacturing', 'Egypt', 1671.00, 20052.00, 2.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (154, 'Eala', 'Dahbur', 'Female', '2019-03-27', 6, 'Account Management', 'United Arab Emirates', 1877.00, 22524.00, 4.50, 1, 0, 0.00);
INSERT INTO public.employees VALUES (155, 'Rwbyna', 'Iibrahim', 'Female', '2019-03-05', 6, 'IT', 'United Arab Emirates', 1960.00, 23520.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (156, 'Tariq', 'Salim', 'Male', '2018-07-19', 6, 'Manufacturing', 'United Arab Emirates', 2422.00, 29064.00, 4.50, 0, 2, 10.00);
INSERT INTO public.employees VALUES (157, 'Basimah', 'Sybea', 'Female', '2019-08-06', 5, 'Manufacturing', 'Saudi Arabia', 1299.00, 15588.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (158, 'Zunar', 'Eali', 'Male', '2020-03-18', 5, 'Major Mfg Projects', 'Egypt', 2127.00, 25524.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (159, 'Rim', 'Mia', 'Female', '2019-07-07', 5, 'Quality Control', 'Egypt', 3096.00, 37152.00, 2.00, 5, 0, 9.00);
INSERT INTO public.employees VALUES (160, 'Lana', 'Alhabash', 'Female', '2016-02-05', 9, 'Manufacturing', 'Egypt', 951.00, 11412.00, 1.00, 6, 0, 8.00);
INSERT INTO public.employees VALUES (161, 'Muhamad', 'Alshghry', 'Male', '2020-05-16', 4, 'Manufacturing', 'Egypt', 2940.00, 35280.00, 1.00, 6, 0, 13.00);
INSERT INTO public.employees VALUES (162, 'Ghazal', 'Hisan', 'Female', '2020-09-28', 4, 'Facilities/Engineering', 'Saudi Arabia', 3293.00, 39516.00, 4.50, 1, 6, 9.00);
INSERT INTO public.employees VALUES (163, 'Khalil', 'Alzaebii', 'Male', '2017-04-15', 8, 'Marketing', 'United Arab Emirates', 3250.00, 39000.00, 2.00, 1, 0, 8.00);
INSERT INTO public.employees VALUES (164, 'Samir', 'Shalish', 'Male', '2018-10-12', 6, 'Account Management', 'Egypt', 2085.00, 25020.00, 3.00, 1, 0, 9.00);
INSERT INTO public.employees VALUES (165, 'Abdalmjid', 'Ahmad', 'Male', '2019-06-22', 5, 'Manufacturing', 'Lebanon', 1578.00, 18936.00, 3.00, 0, 0, 15.00);
INSERT INTO public.employees VALUES (166, 'Emar', 'Abil', 'Female', '2019-09-17', 5, 'Account Management', 'United Arab Emirates', 1169.00, 14028.00, 3.00, 1, 0, 10.00);
INSERT INTO public.employees VALUES (167, 'Lamia', 'Warur', 'Female', '2017-07-11', 7, 'Account Management', 'Saudi Arabia', 1054.00, 12648.00, 5.00, 4, 6, 7.00);
INSERT INTO public.employees VALUES (168, 'Fyfian', 'Abu', 'Female', '2019-08-03', 5, 'Account Management', 'Egypt', 1349.00, 16188.00, 4.50, 1, 0, 4.00);
INSERT INTO public.employees VALUES (169, 'Majd', 'Yasin', 'Female', '2019-04-16', 6, 'Quality Control', 'United Arab Emirates', 2196.00, 26352.00, 5.00, 4, 0, 9.00);
INSERT INTO public.employees VALUES (170, 'Alaa', 'Almisri', 'Female', '2020-01-16', 5, 'Quality Assurance', 'Egypt', 3264.00, 39168.00, 5.00, 6, 5, 4.00);
INSERT INTO public.employees VALUES (171, 'Muhamad', 'Amir', 'Male', '2017-07-26', 7, 'Quality Control', 'United Arab Emirates', 1232.00, 14784.00, 5.00, 4, 5, 2.00);
INSERT INTO public.employees VALUES (172, 'Lilas', 'Balatah', 'Female', '2019-11-18', 5, 'IT', 'Egypt', 2401.00, 28812.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (173, 'Ruaa', 'Mukiin', 'Female', '2017-09-16', 7, 'Manufacturing', 'Saudi Arabia', 3168.00, 38016.00, 5.00, 0, 0, 18.00);
INSERT INTO public.employees VALUES (174, 'Rana', 'Shaeban', 'Female', '2018-02-17', 7, 'Quality Assurance', 'Egypt', 1620.00, 19440.00, 5.00, 5, 0, 10.00);
INSERT INTO public.employees VALUES (175, 'Muwmin', 'Ewad', 'Male', '2017-06-06', 7, 'Quality Control', 'United Arab Emirates', 1482.00, 17784.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (176, 'Rahaf', 'Alaleppoy', 'Female', '2020-04-18', 5, 'Account Management', 'Egypt', 1967.00, 23604.00, 4.50, 6, 0, 6.00);
INSERT INTO public.employees VALUES (177, 'Samiah', 'Alsaedi', 'Female', '2018-03-16', 7, 'Manufacturing', 'Egypt', 1696.00, 20352.00, 5.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (178, 'Rim', 'Hamdu', 'Female', '2018-12-24', 6, 'Facilities/Engineering', 'Egypt', 2913.00, 34956.00, 4.50, 0, 0, 3.00);
INSERT INTO public.employees VALUES (179, 'Aishah', 'Alquatliu', 'Female', '2020-03-07', 5, 'Quality Assurance', 'Lebanon', 2068.00, 24816.00, 1.00, 0, 1, 0.00);
INSERT INTO public.employees VALUES (180, 'Dany', 'Albaba', 'Male', '2018-10-25', 6, 'Environmental Health/Safety', 'United Arab Emirates', 1430.00, 17160.00, 3.00, 6, 0, 0.00);
INSERT INTO public.employees VALUES (181, 'Muhamad', 'Rinkusi', 'Male', '2018-05-30', 6, 'Account Management', 'Saudi Arabia', 3138.00, 37656.00, 1.00, 0, 5, 9.00);
INSERT INTO public.employees VALUES (182, 'Isam', 'Jadid', 'Male', '2020-12-04', 4, 'Manufacturing', 'Egypt', 2051.00, 24612.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (183, 'Bushraa', 'Drwysh', 'Female', '2018-09-08', 6, 'Facilities/Engineering', 'Egypt', 2986.00, 35832.00, 1.00, 3, 0, 8.00);
INSERT INTO public.employees VALUES (184, 'Zakarian', 'Rashwani', 'Male', '2019-02-28', 6, 'Manufacturing', 'Syria', 2790.00, 33480.00, 5.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (185, 'Fadi', 'Alqadi', 'Male', '2020-12-17', 4, 'Facilities/Engineering', 'Egypt', 1075.00, 12900.00, 4.50, 6, 0, 7.00);
INSERT INTO public.employees VALUES (186, 'Diea', 'Almarstani', 'Male', '2019-05-07', 6, 'Sales', 'Syria', 2009.00, 24108.00, 1.00, 5, 0, 0.00);
INSERT INTO public.employees VALUES (187, 'Muhamad', 'Siedih', 'Male', '2018-08-03', 6, 'Training', 'Egypt', 3254.00, 39048.00, 3.00, 4, 6, 5.00);
INSERT INTO public.employees VALUES (188, 'Bisam', 'Almisri', 'Female', '2019-10-17', 5, 'Creative', 'United Arab Emirates', 2367.00, 28404.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (189, 'Muhamad', 'Alkhatib', 'Male', '2018-02-02', 7, 'Manufacturing', 'United Arab Emirates', 3158.00, 37896.00, 3.00, 2, 5, 10.00);
INSERT INTO public.employees VALUES (190, 'Muhamad', 'Rghid', 'Male', '2019-12-27', 5, 'Manufacturing', 'United Arab Emirates', 1980.00, 23760.00, 2.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (191, 'Omar', 'Shakir', 'Male', '2019-04-07', 6, 'Account Management', 'Egypt', 2049.00, 24588.00, 3.00, 6, 0, 23.00);
INSERT INTO public.employees VALUES (192, 'Aryj', 'Hamada', 'Female', '2020-05-27', 4, 'Quality Assurance', 'Egypt', 2727.00, 32724.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (193, 'Madlin', 'Saeid', 'Female', '2019-12-07', 5, 'Manufacturing', 'United Arab Emirates', 974.00, 11688.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (194, 'Rybal', 'Sabagh', 'Male', '2019-11-06', 5, 'Product Development', 'United Arab Emirates', 992.00, 11904.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (195, 'Samar', 'Alqutb', 'Female', '2018-08-17', 6, 'Account Management', 'Egypt', 2730.00, 32760.00, 1.00, 4, 6, 9.00);
INSERT INTO public.employees VALUES (196, 'Eala', 'Murad', 'Female', '2016-01-18', 9, 'Facilities/Engineering', 'Egypt', 2804.00, 33648.00, 4.50, 0, 0, 4.00);
INSERT INTO public.employees VALUES (197, 'Ahmad', 'Salih', 'Male', '2019-04-03', 6, 'Quality Control', 'Egypt', 1467.00, 17604.00, 5.00, 6, 0, 0.00);
INSERT INTO public.employees VALUES (198, 'Ibrahim', 'Alhamid', 'Male', '2020-11-06', 4, 'Major Mfg Projects', 'Lebanon', 997.00, 11964.00, 5.00, 1, 0, 68.00);
INSERT INTO public.employees VALUES (199, 'Muhamad', 'Alziyat', 'Male', '2019-08-28', 5, 'Account Management', 'Saudi Arabia', 1859.00, 22308.00, 5.00, 5, 0, 1.00);
INSERT INTO public.employees VALUES (200, 'Ali', 'Nhl', 'Male', '2019-09-03', 5, 'Quality Assurance', 'Egypt', 1231.00, 14772.00, 1.00, 1, 5, 7.00);
INSERT INTO public.employees VALUES (201, 'Saed', 'Alsiyah', 'Male', '2019-07-19', 5, 'Manufacturing', 'Egypt', 719.00, 8628.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (202, 'Majdy', 'Rafaea', 'Male', '2020-05-31', 4, 'Environmental Compliance', 'United Arab Emirates', 2186.00, 26232.00, 1.00, 2, 0, 10.00);
INSERT INTO public.employees VALUES (203, 'Ihsan', 'Eazu', 'Male', '2019-05-18', 5, 'Professional Training Group', 'Egypt', 1605.00, 19260.00, 4.50, 5, 4, 9.00);
INSERT INTO public.employees VALUES (204, 'Iad', 'Alshaykh', 'Male', '2018-05-17', 6, 'Facilities/Engineering', 'Egypt', 2365.00, 28380.00, 1.00, 0, 0, 73.00);
INSERT INTO public.employees VALUES (205, 'Bara', 'Alrrashid', 'Male', '2017-04-17', 8, 'Research Center', 'Syria', 1096.00, 13152.00, 4.50, 4, 0, 8.00);
INSERT INTO public.employees VALUES (206, 'Fadi', 'Nuna', 'Male', '2019-07-08', 5, 'Facilities/Engineering', 'Egypt', 1037.00, 12444.00, 3.00, 6, 0, 5.00);
INSERT INTO public.employees VALUES (207, 'Muhamad', 'Salah', 'Male', '2020-12-03', 4, 'Facilities/Engineering', 'Syria', 1757.00, 21084.00, 2.00, 6, 0, 13.00);
INSERT INTO public.employees VALUES (208, 'Bima', 'Mustafaa', 'Female', '2020-11-03', 4, 'Quality Assurance', 'Egypt', 3405.00, 40860.00, 5.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (209, 'Husam', 'Abu Shwmr', 'Male', '2018-06-11', 6, 'Account Management', 'United Arab Emirates', 2154.00, 25848.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (210, 'Abdalrahmin', 'Turkmany', 'Male', '2019-02-12', 6, 'Marketing', 'Egypt', 805.00, 9660.00, 2.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (211, 'Majdulyn', 'Alhakim', 'Female', '2018-10-03', 6, 'Human Resources', 'Egypt', 3093.00, 37116.00, 4.50, 0, 0, 10.00);
INSERT INTO public.employees VALUES (212, 'Ahmad', 'Abu Jaysh', 'Male', '2017-08-10', 7, 'Creative', 'Saudi Arabia', 1039.00, 12468.00, 3.00, 2, 0, 87.00);
INSERT INTO public.employees VALUES (213, 'Majid', 'Aleusud', 'Male', '2019-11-23', 5, 'Account Management', 'Egypt', 1012.00, 12144.00, 3.00, 1, 0, 7.00);
INSERT INTO public.employees VALUES (214, 'Bashshar', 'Shakhashiru', 'Male', '2017-06-13', 7, 'Sales', 'Egypt', 2216.00, 26592.00, 2.00, 0, 0, 11.00);
INSERT INTO public.employees VALUES (215, 'Malik', 'Alshaykh', 'Male', '2020-11-28', 4, 'Quality Assurance', 'Egypt', 2020.00, 24240.00, 4.50, 0, 5, 0.00);
INSERT INTO public.employees VALUES (216, 'Omar', 'Zarzur', 'Male', '2016-11-06', 8, 'Product Development', 'United Arab Emirates', 3309.00, 39708.00, 4.50, 1, 0, 7.00);
INSERT INTO public.employees VALUES (217, 'Hasan', 'Iismaeil', 'Male', '2020-05-05', 5, 'Account Management', 'United Arab Emirates', 983.00, 11796.00, 2.00, 6, 0, 0.00);
INSERT INTO public.employees VALUES (218, 'Husayn', 'Abu Nasir', 'Male', '2018-03-25', 7, 'Manufacturing', 'Egypt', 741.00, 8892.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (219, 'Mazin', 'Earabi', 'Male', '2016-09-13', 8, 'Account Management', 'United Arab Emirates', 1171.00, 14052.00, 4.50, 0, 0, 0.00);
INSERT INTO public.employees VALUES (220, 'Zahir', 'Eisaa', 'Male', '2019-12-18', 5, 'Quality Assurance', 'Egypt', 2512.00, 30144.00, 5.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (221, 'Lama', 'Sabiq', 'Female', '2019-03-29', 6, 'Quality Control', 'Egypt', 1608.00, 19296.00, 1.00, 0, 3, 4.00);
INSERT INTO public.employees VALUES (222, 'Tariq', 'Dw', 'Male', '2020-04-24', 5, 'Quality Assurance', 'United Arab Emirates', 1677.00, 20124.00, 1.00, 0, 0, 12.00);
INSERT INTO public.employees VALUES (223, 'Jawaher', 'Shaykhus', 'Female', '2018-04-25', 7, 'Quality Assurance', 'Egypt', 3414.00, 40968.00, 5.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (224, 'Emam', 'Mansur', 'Male', '2019-03-29', 6, 'Quality Assurance', 'Lebanon', 1358.00, 16296.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (225, 'Muhamad', 'Bulta', 'Male', '2019-08-17', 5, 'Account Management', 'Egypt', 703.00, 8436.00, 4.50, 0, 0, 64.00);
INSERT INTO public.employees VALUES (226, 'Fatin', 'Hamshu', 'Female', '2018-12-09', 6, 'Product Development', 'Egypt', 2017.00, 24204.00, 2.00, 0, 1, 8.00);
INSERT INTO public.employees VALUES (227, 'Abd Alruhmin', 'Alnasar', 'Male', '2019-08-10', 5, 'Product Development', 'Egypt', 1806.00, 21672.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (228, 'Fatin', 'Red', 'Female', '2019-07-17', 5, 'Creative', 'Egypt', 2421.00, 29052.00, 3.00, 6, 0, 16.00);
INSERT INTO public.employees VALUES (229, 'Ali', 'Muhamad', 'Male', '2018-06-05', 6, 'Marketing', 'United Arab Emirates', 1461.00, 17532.00, 5.00, 1, 0, 7.00);
INSERT INTO public.employees VALUES (230, 'Rima', 'Dwalyby', 'Female', '2020-10-02', 4, 'Manufacturing', 'Egypt', 1287.00, 15444.00, 1.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (231, 'Basil', 'Musaa', 'Male', '2018-05-24', 6, 'Manufacturing', 'Egypt', 2756.00, 33072.00, 3.00, 2, 0, 4.00);
INSERT INTO public.employees VALUES (232, 'Antuan', 'Litansdurfr', 'Male', '2019-01-09', 6, 'Quality Control', 'Egypt', 2332.00, 27984.00, 5.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (233, 'Rashad', 'Iidris', 'Male', '2019-11-26', 5, 'Training', 'Egypt', 812.00, 9744.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (234, 'Bidralidin', 'Ahmdghrybw', 'Male', '2020-09-29', 4, 'Manufacturing', 'Egypt', 2651.00, 31812.00, 1.00, 0, 0, 12.00);
INSERT INTO public.employees VALUES (235, 'Faras', 'Shaykh', 'Male', '2019-03-23', 6, 'Sales', 'United Arab Emirates', 2331.00, 27972.00, 4.50, 0, 0, 9.00);
INSERT INTO public.employees VALUES (236, 'Muhamad', 'Eala Aldiyn', 'Male', '2019-12-27', 5, 'Sales', 'Saudi Arabia', 2162.00, 25944.00, 5.00, 0, 0, 13.00);
INSERT INTO public.employees VALUES (237, 'Khaldun', 'Suqbani', 'Male', '2020-06-09', 4, 'Manufacturing', 'Egypt', 1952.00, 23424.00, 3.00, 1, 1, 34.00);
INSERT INTO public.employees VALUES (238, 'Lwna', 'Albahra', 'Female', '2020-04-10', 5, 'Product Development', 'Egypt', 2976.00, 35712.00, 4.50, 0, 2, 6.00);
INSERT INTO public.employees VALUES (239, 'Ahmad', 'Ezqul', 'Male', '2018-06-21', 6, 'Manufacturing', 'Saudi Arabia', 2080.00, 24960.00, 5.00, 0, 5, 13.00);
INSERT INTO public.employees VALUES (240, 'Salih', 'Alhamuwd', 'Male', '2018-11-27', 6, 'Marketing', 'Egypt', 1668.00, 20016.00, 4.50, 0, 3, 3.00);
INSERT INTO public.employees VALUES (241, 'Muhamad', 'Abu Zamil', 'Male', '2016-07-05', 8, 'Marketing', 'Egypt', 2234.00, 26808.00, 5.00, 3, 0, 7.00);
INSERT INTO public.employees VALUES (242, 'Fuad', 'Alsyqly', 'Male', '2019-10-27', 5, 'Account Management', 'Syria', 2096.00, 25152.00, 3.00, 5, 2, 0.00);
INSERT INTO public.employees VALUES (243, 'Muhamad', 'Aldamshqi', 'Male', '2019-05-27', 5, 'Manufacturing', 'Saudi Arabia', 2129.00, 25548.00, 3.00, 1, 1, 3.00);
INSERT INTO public.employees VALUES (244, 'Sayf Aldiyn', 'Alkmshh', 'Male', '2019-02-12', 6, 'Manufacturing', 'Saudi Arabia', 1429.00, 17148.00, 3.00, 0, 5, 8.00);
INSERT INTO public.employees VALUES (245, 'Muhamad', 'Alssati', 'Male', '2020-10-22', 4, 'Manufacturing', 'United Arab Emirates', 1479.00, 17748.00, 3.00, 5, 4, 8.00);
INSERT INTO public.employees VALUES (246, 'Khalid', 'Alem', 'Male', '2020-12-16', 4, 'Quality Control', 'United Arab Emirates', 2884.00, 34608.00, 5.00, 1, 6, 3.00);
INSERT INTO public.employees VALUES (247, 'Ayham', 'Aleisaa', 'Male', '2020-12-02', 4, 'Training', 'Syria', 2947.00, 35364.00, 3.00, 5, 0, 1.00);
INSERT INTO public.employees VALUES (248, 'Abd Alruhmin', 'Dulul', 'Male', '2018-06-24', 6, 'Quality Control', 'Egypt', 1795.00, 21540.00, 1.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (249, 'Ruba', 'Aleid', 'Female', '2018-02-06', 7, 'Account Management', 'Egypt', 1982.00, 23784.00, 5.00, 1, 0, 7.00);
INSERT INTO public.employees VALUES (250, 'Muhamad', 'Badawiin', 'Male', '2020-11-27', 4, 'Account Management', 'Egypt', 2543.00, 30516.00, 5.00, 0, 0, 86.00);
INSERT INTO public.employees VALUES (251, 'Sharihan', 'Rihan', 'Female', '2020-02-08', 5, 'Manufacturing', 'Egypt', 2787.00, 33444.00, 3.00, 3, 0, 12.00);
INSERT INTO public.employees VALUES (252, 'Ibrahim', 'Alyasin', 'Male', '2020-02-04', 5, 'Quality Assurance', 'Egypt', 1095.00, 13140.00, 5.00, 6, 0, 5.00);
INSERT INTO public.employees VALUES (253, 'Iin', 'Mulaliyun', 'Female', '2020-04-15', 5, 'Manufacturing', 'Saudi Arabia', 2009.00, 24108.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (254, 'Danah', 'Almahdi', 'Female', '2016-07-06', 8, 'Environmental Compliance', 'Egypt', 1837.00, 22044.00, 3.00, 1, 0, 2.00);
INSERT INTO public.employees VALUES (255, 'Muhamad', 'Sakar', 'Male', '2019-09-21', 5, 'Training', 'Saudi Arabia', 3109.00, 37308.00, 3.00, 1, 0, 9.00);
INSERT INTO public.employees VALUES (256, 'Lama', 'Yasin', 'Female', '2020-05-31', 4, 'Manufacturing', 'Egypt', 2832.00, 33984.00, 5.00, 1, 0, 5.00);
INSERT INTO public.employees VALUES (257, 'Asf', 'Abultif', 'Male', '2019-01-01', 6, 'Manufacturing', 'Egypt', 2940.00, 35280.00, 1.00, 6, 4, 7.00);
INSERT INTO public.employees VALUES (258, 'Ahmad', 'Alshalaq', 'Male', '2019-04-05', 6, 'Product Development', 'Syria', 983.00, 11796.00, 5.00, 0, 0, 13.00);
INSERT INTO public.employees VALUES (259, 'Mazin', 'Zawal', 'Male', '2020-04-20', 5, 'IT', 'Egypt', 1223.00, 14676.00, 1.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (260, 'Diana', 'Aleabd', 'Female', '2020-07-13', 4, 'Research/Development', 'Egypt', 833.00, 9996.00, 1.00, 1, 0, 5.00);
INSERT INTO public.employees VALUES (261, 'Kawkab', 'Qarqazan', 'Female', '2018-05-10', 7, 'Quality Control', 'Egypt', 2074.00, 24888.00, 3.00, 1, 0, 2.00);
INSERT INTO public.employees VALUES (262, 'Thamir', 'Abu Ghazy', 'Male', '2018-03-12', 7, 'Quality Control', 'United Arab Emirates', 2811.00, 33732.00, 3.00, 0, 1, 9.00);
INSERT INTO public.employees VALUES (263, 'Muhamad', 'Alabth', 'Male', '2019-09-23', 5, 'Quality Control', 'Saudi Arabia', 1436.00, 17232.00, 4.50, 3, 4, 4.00);
INSERT INTO public.employees VALUES (264, 'Khadijah', 'Abu Taqih', 'Female', '2019-07-01', 5, 'Manufacturing', 'Egypt', 1041.00, 12492.00, 2.00, 2, 0, 5.00);
INSERT INTO public.employees VALUES (265, 'Salwaa', 'Alsyd', 'Female', '2018-06-15', 6, 'Quality Control', 'Egypt', 2231.00, 26772.00, 3.00, 0, 0, 87.00);
INSERT INTO public.employees VALUES (266, 'Muayid', 'Shbyb', 'Male', '2019-02-16', 6, 'Marketing', 'United Arab Emirates', 1036.00, 12432.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (267, 'Rannym', 'Tyru', 'Female', '2020-10-15', 4, 'Quality Control', 'Egypt', 2143.00, 25716.00, 5.00, 0, 0, 45.00);
INSERT INTO public.employees VALUES (268, 'Iin', 'Alhaju Bikr', 'Female', '2020-01-07', 5, 'Quality Assurance', 'United Arab Emirates', 967.00, 11604.00, 5.00, 0, 4, 9.00);
INSERT INTO public.employees VALUES (269, 'Jihad', 'Aldukifi', 'Male', '2020-07-16', 4, 'Product Development', 'Egypt', 2510.00, 30120.00, 1.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (270, 'Sandurana', 'Antun', 'Female', '2019-03-31', 6, 'Marketing', 'Egypt', 3364.00, 40368.00, 2.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (271, 'Eala', 'Darkzifli', 'Female', '2019-01-06', 6, 'Quality Assurance', 'Egypt', 3420.00, 41040.00, 5.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (272, 'Samir', 'Alsaeid', 'Male', '2019-09-14', 5, 'Creative', 'United Arab Emirates', 2229.00, 26748.00, 3.00, 3, 0, 1.00);
INSERT INTO public.employees VALUES (273, 'Amir', 'Alhifar', 'Male', '2020-05-27', 4, 'Creative', 'Egypt', 1910.00, 22920.00, 5.00, 2, 0, 5.00);
INSERT INTO public.employees VALUES (274, 'Lama', 'Almala', 'Female', '2019-08-07', 5, 'Training', 'Egypt', 1917.00, 23004.00, 4.50, 0, 1, 84.00);
INSERT INTO public.employees VALUES (275, 'Hasan', 'Kalthum', 'Male', '2018-12-20', 6, 'Quality Control', 'Egypt', 831.00, 9972.00, 1.00, 1, 2, 7.00);
INSERT INTO public.employees VALUES (276, 'Muhamad', 'Saeadat', 'Male', '2019-07-06', 5, 'Quality Control', 'United Arab Emirates', 2636.00, 31632.00, 4.50, 0, 2, 4.00);
INSERT INTO public.employees VALUES (277, 'Rana', 'Eijrush', 'Female', '2018-09-05', 6, 'Account Management', 'Syria', 2929.00, 35148.00, 2.00, 0, 1, 4.00);
INSERT INTO public.employees VALUES (278, 'Tariq', 'Alkinaya', 'Male', '2019-10-26', 5, 'Quality Control', 'Egypt', 1255.00, 15060.00, 1.00, 6, 0, 15.00);
INSERT INTO public.employees VALUES (279, 'Amjad', 'Alrz', 'Male', '2020-04-12', 5, 'Quality Control', 'United Arab Emirates', 2210.00, 26520.00, 3.00, 0, 0, 13.00);
INSERT INTO public.employees VALUES (280, 'Daniah', 'Alhariri', 'Female', '2019-10-15', 5, 'Quality Control', 'Egypt', 1788.00, 21456.00, 5.00, 1, 0, 9.00);
INSERT INTO public.employees VALUES (281, 'Hasan', 'Quidr', 'Male', '2020-04-30', 5, 'Quality Control', 'Egypt', 2488.00, 29856.00, 5.00, 0, 5, 3.00);
INSERT INTO public.employees VALUES (282, 'Muhamad', 'Shaykh Janid', 'Male', '2020-04-18', 5, 'Manufacturing', 'Egypt', 2187.00, 26244.00, 5.00, 1, 3, 2.00);
INSERT INTO public.employees VALUES (283, 'Esamat', 'Zaza', 'Male', '2020-05-12', 5, 'Quality Control', 'Egypt', 1366.00, 16392.00, 2.00, 0, 0, 13.00);
INSERT INTO public.employees VALUES (284, 'Fadi', 'Hububati', 'Male', '2019-05-06', 6, 'Quality Assurance', 'Egypt', 2612.00, 31344.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (285, 'Adnan', 'Alhusayn', 'Male', '2018-04-09', 7, 'Account Management', 'United Arab Emirates', 2246.00, 26952.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (286, 'Muhamad', 'Allibad', 'Male', '2018-07-26', 6, 'Quality Control', 'Egypt', 2761.00, 33132.00, 5.00, 0, 2, 5.00);
INSERT INTO public.employees VALUES (287, 'Tana', 'Dahruj', 'Female', '2019-12-01', 5, 'Creative', 'Egypt', 1536.00, 18432.00, 4.50, 0, 0, 76.00);
INSERT INTO public.employees VALUES (288, 'Muhamad', 'Almtlq', 'Male', '2016-11-10', 8, 'Professional Training Group', 'Saudi Arabia', 2180.00, 26160.00, 4.50, 0, 0, 80.00);
INSERT INTO public.employees VALUES (289, 'Sana', 'Alhusayn', 'Female', '2019-12-23', 5, 'Account Management', 'Egypt', 3412.00, 40944.00, 5.00, 2, 0, 3.00);
INSERT INTO public.employees VALUES (290, 'Muhamad', 'Bdraldyn', 'Male', '2018-05-30', 6, 'Facilities/Engineering', 'Egypt', 2546.00, 30552.00, 4.50, 0, 0, 6.00);
INSERT INTO public.employees VALUES (291, 'Muhamad', 'Eataya', 'Male', '2017-12-27', 7, 'Research/Development', 'Egypt', 1856.00, 22272.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (292, 'Fadi', 'Aljizamati', 'Male', '2019-06-02', 5, 'Product Development', 'Egypt', 3220.00, 38640.00, 5.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (293, 'Alaa', 'Alqasir', 'Male', '2016-04-13', 9, 'Manufacturing', 'Saudi Arabia', 3061.00, 36732.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (294, 'Abd Alruhmin', 'Salih', 'Male', '2017-08-26', 7, 'Training', 'Saudi Arabia', 2221.00, 26652.00, 2.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (295, 'Shilan', 'Ahmad', 'Female', '2017-04-27', 8, 'Quality Control', 'Saudi Arabia', 1799.00, 21588.00, 4.50, 2, 0, 6.00);
INSERT INTO public.employees VALUES (296, 'Hasan', 'Aljasim', 'Male', '2017-05-24', 7, 'Account Management', 'Egypt', 2082.00, 24984.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (297, 'Khalil', 'Salam', 'Male', '2016-08-23', 8, 'Creative', 'United Arab Emirates', 1490.00, 17880.00, 4.50, 0, 2, 6.00);
INSERT INTO public.employees VALUES (298, 'Majd', 'Abuhamd', 'Female', '2020-03-15', 5, 'Account Management', 'United Arab Emirates', 2042.00, 24504.00, 4.50, 0, 0, 10.00);
INSERT INTO public.employees VALUES (299, 'Sami', 'Qareush', 'Male', '2016-05-02', 9, 'Marketing', 'Syria', 985.00, 11820.00, 5.00, 1, 0, 5.00);
INSERT INTO public.employees VALUES (300, 'Rima', 'Jaridiun', 'Female', '2017-05-05', 8, 'Sales', 'Egypt', 1988.00, 23856.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (301, 'Iin', 'Alhumwi', 'Female', '2018-07-05', 6, 'Account Management', 'Saudi Arabia', 1545.00, 18540.00, 5.00, 1, 0, 1.00);
INSERT INTO public.employees VALUES (302, 'Akthum', 'Eibdalbaqi', 'Male', '2020-07-04', 4, 'Training', 'Egypt', 2637.00, 31644.00, 5.00, 0, 0, 50.00);
INSERT INTO public.employees VALUES (303, 'Muhamad', 'Almurashihi', 'Male', '2019-12-11', 5, 'Manufacturing', 'Saudi Arabia', 1385.00, 16620.00, 4.50, 0, 0, 6.00);
INSERT INTO public.employees VALUES (304, 'Batual', 'Abu Fakhar', 'Female', '2018-02-05', 7, 'Manufacturing', 'United Arab Emirates', 2468.00, 29616.00, 1.00, 4, 0, 3.00);
INSERT INTO public.employees VALUES (305, 'Rinah', 'Alkhuriu', 'Female', '2018-06-29', 6, 'Professional Training Group', 'Syria', 2098.00, 25176.00, 4.50, 0, 0, 3.00);
INSERT INTO public.employees VALUES (306, 'Muhamad', 'Alsaqaraq', 'Male', '2019-05-22', 5, 'Marketing', 'United Arab Emirates', 2302.00, 27624.00, 3.00, 6, 0, 6.00);
INSERT INTO public.employees VALUES (307, 'Diea', 'Sharina', 'Male', '2019-04-10', 6, 'Facilities/Engineering', 'Egypt', 1623.00, 19476.00, 1.00, 6, 0, 4.00);
INSERT INTO public.employees VALUES (308, 'Jablah', 'Alsulayman', 'Female', '2019-03-13', 6, 'Quality Assurance', 'Lebanon', 1333.00, 15996.00, 3.00, 1, 6, 10.00);
INSERT INTO public.employees VALUES (309, 'Muhamad', 'Almaghribiu', 'Male', '2016-11-18', 8, 'Quality Control', 'United Arab Emirates', 1431.00, 17172.00, 5.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (310, 'Kholoud', 'Khayti', 'Female', '2019-12-24', 5, 'Manufacturing', 'Egypt', 2527.00, 30324.00, 3.00, 0, 0, 98.00);
INSERT INTO public.employees VALUES (311, 'Rahaf', 'Jamul', 'Female', '2017-02-06', 8, 'Manufacturing', 'Egypt', 2631.00, 31572.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (312, 'Faras', 'Alrahil', 'Male', '2018-03-12', 7, 'Marketing', 'Egypt', 1600.00, 19200.00, 4.50, 0, 0, 0.00);
INSERT INTO public.employees VALUES (313, 'Abd Alrazzaq', 'Gharah', 'Male', '2020-12-16', 4, 'Environmental Compliance', 'Egypt', 2752.00, 33024.00, 5.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (314, 'Alaa', 'Saed', 'Female', '2020-06-16', 4, 'Quality Control', 'Egypt', 3125.00, 37500.00, 5.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (315, 'Lylas', 'Shiah', 'Female', '2019-07-02', 5, 'IT', 'Saudi Arabia', 2091.00, 25092.00, 2.00, 0, 1, 9.00);
INSERT INTO public.employees VALUES (316, 'Kinda', 'Alaqre', 'Female', '2016-12-22', 8, 'Marketing', 'United Arab Emirates', 1009.00, 12108.00, 4.50, 0, 0, 17.00);
INSERT INTO public.employees VALUES (317, 'Muhamad', 'Almisri', 'Male', '2020-10-11', 4, 'Quality Control', 'Saudi Arabia', 3443.00, 41316.00, 1.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (318, 'Dinana', 'Zaydan', 'Female', '2018-03-23', 7, 'Manufacturing', 'Syria', 1582.00, 18984.00, 4.50, 0, 0, 5.00);
INSERT INTO public.employees VALUES (319, 'Amyrah', 'Mudinih', 'Female', '2019-03-04', 6, 'Marketing', 'United Arab Emirates', 2103.00, 25236.00, 5.00, 1, 1, 2.00);
INSERT INTO public.employees VALUES (320, 'Safa', 'AlAhmar', 'Female', '2018-01-06', 7, 'Environmental Compliance', 'Egypt', 3108.00, 37296.00, 1.00, 0, 0, 45.00);
INSERT INTO public.employees VALUES (321, 'Ahmad', 'Eurman', 'Male', '2016-08-19', 8, 'Manufacturing', 'Egypt', 1810.00, 21720.00, 3.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (322, 'Abd Allah', 'Almawsiliu', 'Male', '2018-08-10', 6, 'Creative', 'Saudi Arabia', 2312.00, 27744.00, 3.00, 3, 0, 10.00);
INSERT INTO public.employees VALUES (323, 'Majd', 'Eisaa', 'Female', '2020-06-11', 4, 'Facilities/Engineering', 'Egypt', 2783.00, 33396.00, 1.00, 2, 0, 15.00);
INSERT INTO public.employees VALUES (324, 'Muhamad', 'Salhany', 'Male', '2020-12-02', 4, 'Quality Control', 'Egypt', 3428.00, 41136.00, 3.00, 5, 0, 10.00);
INSERT INTO public.employees VALUES (325, 'Ashraf', 'Aleid', 'Male', '2018-02-05', 7, 'Account Management', 'Egypt', 3450.00, 41400.00, 2.00, 0, 4, 9.00);
INSERT INTO public.employees VALUES (326, 'Muhamad', 'Shadi Alghazy', 'Male', '2018-09-19', 6, 'Research Center', 'United Arab Emirates', 1226.00, 14712.00, 2.00, 6, 5, 4.00);
INSERT INTO public.employees VALUES (327, 'Muhamad', 'Husayn', 'Male', '2019-08-30', 5, 'Quality Assurance', 'Egypt', 3219.00, 38628.00, 3.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (328, 'Mazin', 'Bytar', 'Male', '2019-04-19', 6, 'Quality Control', 'Saudi Arabia', 2060.00, 24720.00, 5.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (329, 'Iin', 'Farahat', 'Female', '2019-01-18', 6, 'IT', 'Syria', 2479.00, 29748.00, 5.00, 0, 2, 3.00);
INSERT INTO public.employees VALUES (330, 'Lama', 'Albazir', 'Female', '2018-05-28', 6, 'Product Development', 'United Arab Emirates', 2106.00, 25272.00, 3.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (331, 'Emar', 'Alnisrin', 'Female', '2019-06-07', 5, 'Manufacturing', 'Saudi Arabia', 1480.00, 17760.00, 2.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (332, 'Afra', 'Sharabi', 'Female', '2017-11-19', 7, 'Manufacturing', 'Egypt', 994.00, 11928.00, 1.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (333, 'Ahmad', 'Hamuwd', 'Male', '2019-11-28', 5, 'Facilities/Engineering', 'United Arab Emirates', 2119.00, 25428.00, 4.50, 1, 5, 0.00);
INSERT INTO public.employees VALUES (334, 'Ramiz', 'Aleuryan', 'Male', '2018-10-05', 6, 'IT', 'Egypt', 1577.00, 18924.00, 4.50, 0, 0, 7.00);
INSERT INTO public.employees VALUES (335, 'Iad', 'Eaku', 'Male', '2018-05-04', 7, 'Quality Control', 'United Arab Emirates', 3160.00, 37920.00, 5.00, 0, 5, 10.00);
INSERT INTO public.employees VALUES (336, 'Husayn', 'Euthman', 'Male', '2020-10-19', 4, 'Professional Training Group', 'Saudi Arabia', 2692.00, 32304.00, 1.00, 4, 0, 6.00);
INSERT INTO public.employees VALUES (337, 'Imran', 'Hazruma', 'Male', '2018-11-26', 6, 'Account Management', 'United Arab Emirates', 1448.00, 17376.00, 4.50, 0, 0, 1.00);
INSERT INTO public.employees VALUES (338, 'Rawan', 'Durkzili', 'Female', '2019-03-17', 6, 'Manufacturing', 'Egypt', 1568.00, 18816.00, 3.00, 5, 0, 7.00);
INSERT INTO public.employees VALUES (339, 'Muayid', 'Shaqir', 'Male', '2016-12-20', 8, 'Facilities/Engineering', 'Egypt', 1823.00, 21876.00, 4.50, 5, 0, 9.00);
INSERT INTO public.employees VALUES (340, 'Muanis', 'Alsabagh', 'Male', '2019-02-16', 6, 'Manufacturing', 'Egypt', 1712.00, 20544.00, 4.50, 0, 4, 15.00);
INSERT INTO public.employees VALUES (341, 'Dijwar', 'Husu', 'Male', '2020-10-30', 4, 'Product Development', 'United Arab Emirates', 744.00, 8928.00, 5.00, 5, 0, 8.00);
INSERT INTO public.employees VALUES (342, 'Asama', 'Eilwan', 'Female', '2017-07-29', 7, 'Manufacturing', 'Egypt', 2972.00, 35664.00, 5.00, 0, 4, 2.00);
INSERT INTO public.employees VALUES (343, 'Esamat', 'Alhidad', 'Male', '2019-11-16', 5, 'Account Management', 'Egypt', 2931.00, 35172.00, 3.00, 6, 0, 71.00);
INSERT INTO public.employees VALUES (344, 'Tariq', 'Zaeur', 'Male', '2018-07-20', 6, 'Creative', 'Syria', 2544.00, 30528.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (345, 'Rasul', 'Aleumurii', 'Male', '2016-08-23', 8, 'Manufacturing', 'Saudi Arabia', 1595.00, 19140.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (346, 'Rawan', 'Albaytar', 'Female', '2018-12-05', 6, 'Account Management', 'Syria', 1326.00, 15912.00, 3.00, 0, 3, 7.00);
INSERT INTO public.employees VALUES (347, 'Omar', 'Altuean', 'Male', '2019-01-27', 6, 'Marketing', 'Egypt', 3117.00, 37404.00, 3.00, 0, 4, 0.00);
INSERT INTO public.employees VALUES (348, 'Dalia', 'Hamdan', 'Female', '2019-02-11', 6, 'Major Mfg Projects', 'Egypt', 3446.00, 41352.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (349, 'Omar', 'Alhindi', 'Male', '2019-01-11', 6, 'Manufacturing', 'United Arab Emirates', 2023.00, 24276.00, 4.50, 6, 0, 6.00);
INSERT INTO public.employees VALUES (350, 'Ali', 'Zyny', 'Male', '2020-08-01', 4, 'Quality Assurance', 'Egypt', 979.00, 11748.00, 3.00, 6, 0, 4.00);
INSERT INTO public.employees VALUES (351, 'Almuetaz', 'Biallah', 'Male', '2020-08-21', 4, 'Environmental Health/Safety', 'Egypt', 1676.00, 20112.00, 4.50, 0, 0, 8.00);
INSERT INTO public.employees VALUES (352, 'Rabana', 'Alsaman', 'Female', '2017-01-12', 8, 'Sales', 'Egypt', 3079.00, 36948.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (353, 'Ghada', 'Khalid', 'Female', '2019-07-29', 5, 'IT', 'Egypt', 2164.00, 25968.00, 3.00, 0, 2, 0.00);
INSERT INTO public.employees VALUES (354, 'Esamat', 'Alriys', 'Male', '2020-11-11', 4, 'Manufacturing', 'Egypt', 2312.00, 27744.00, 3.00, 0, 0, 31.00);
INSERT INTO public.employees VALUES (355, 'Amir', 'Alkhatib', 'Male', '2017-08-27', 7, 'Account Management', 'Egypt', 834.00, 10008.00, 2.00, 6, 0, 13.00);
INSERT INTO public.employees VALUES (356, 'Samirah', 'Jumea', 'Female', '2019-01-15', 6, 'Quality Control', 'Egypt', 723.00, 8676.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (357, 'Samir', 'Alhaj Ali', 'Male', '2016-05-14', 8, 'Quality Assurance', 'Egypt', 2807.00, 33684.00, 3.00, 5, 1, 2.00);
INSERT INTO public.employees VALUES (358, 'Farial', 'Qulumih', 'Female', '2017-06-18', 7, 'Marketing', 'Saudi Arabia', 1002.00, 12024.00, 5.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (359, 'Salih', 'Dawara', 'Male', '2020-07-11', 4, 'Creative', 'Egypt', 2265.00, 27180.00, 5.00, 1, 0, 9.00);
INSERT INTO public.employees VALUES (360, 'Abdalhadi', 'Salim', 'Male', '2019-10-15', 5, 'Quality Control', 'Egypt', 3283.00, 39396.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (361, 'Ruaa', 'Qahraman', 'Female', '2018-04-14', 7, 'Quality Assurance', 'Egypt', 2675.00, 32100.00, 3.00, 1, 6, 4.00);
INSERT INTO public.employees VALUES (362, 'Muhamad', 'Mshati', 'Male', '2019-01-16', 6, 'Marketing', 'United Arab Emirates', 3056.00, 36672.00, 4.50, 0, 0, 9.00);
INSERT INTO public.employees VALUES (363, 'Shadi', 'Altibae', 'Male', '2019-10-14', 5, 'Manufacturing', 'Egypt', 1579.00, 18948.00, 3.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (364, 'Ahmad', 'Iidlibi', 'Male', '2019-06-06', 5, 'Marketing', 'Saudi Arabia', 1255.00, 15060.00, 3.00, 6, 0, 0.00);
INSERT INTO public.employees VALUES (365, 'Fadi', 'Ghazzawi', 'Male', '2019-01-31', 6, 'Quality Control', 'Egypt', 3418.00, 41016.00, 3.00, 4, 0, 1.00);
INSERT INTO public.employees VALUES (366, 'Basil', 'Eabd Aleal', 'Male', '2020-11-30', 4, 'Marketing', 'Egypt', 3368.00, 40416.00, 3.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (367, 'Sali', 'Musuh', 'Female', '2019-11-15', 5, 'Green Building', 'United Arab Emirates', 3275.00, 39300.00, 3.00, 1, 2, 12.00);
INSERT INTO public.employees VALUES (368, 'Alaa', 'Iismaeil', 'Female', '2020-12-27', 4, 'IT', 'United Arab Emirates', 3043.00, 36516.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (369, 'Maria', 'Alhizae', 'Female', '2019-12-04', 5, 'Creative', 'Lebanon', 1122.00, 13464.00, 4.50, 2, 4, 7.00);
INSERT INTO public.employees VALUES (370, 'Ghazal', 'Alghan', 'Female', '2018-03-24', 7, 'Manufacturing', 'Egypt', 764.00, 9168.00, 5.00, 4, 1, 13.00);
INSERT INTO public.employees VALUES (371, 'Eala', 'Mitri', 'Female', '2019-02-02', 6, 'Account Management', 'Saudi Arabia', 2879.00, 34548.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (372, 'Muhamad', 'Aleliwi', 'Male', '2020-02-25', 5, 'Manufacturing', 'United Arab Emirates', 2252.00, 27024.00, 3.00, 1, 0, 50.00);
INSERT INTO public.employees VALUES (373, 'Ahmad', 'Almisri', 'Male', '2018-11-09', 6, 'Product Development', 'United Arab Emirates', 2149.00, 25788.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (374, 'Ahmad', 'Aldwltali', 'Male', '2019-11-08', 5, 'Human Resources', 'United Arab Emirates', 2428.00, 29136.00, 5.00, 0, 0, 35.00);
INSERT INTO public.employees VALUES (375, 'Muhamad', 'Udib', 'Male', '2019-10-12', 5, 'Manufacturing', 'Egypt', 3240.00, 38880.00, 5.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (376, 'Alaa', 'Yuzbik', 'Female', '2018-03-11', 7, 'Account Management', 'Egypt', 1448.00, 17376.00, 3.00, 4, 0, 10.00);
INSERT INTO public.employees VALUES (377, 'Husayn', 'Zaerur', 'Male', '2020-08-01', 4, 'Manufacturing', 'Egypt', 2409.00, 28908.00, 3.00, 3, 3, 3.00);
INSERT INTO public.employees VALUES (378, 'Saeid', 'Mazlum', 'Male', '2019-10-03', 5, 'Professional Training Group', 'United Arab Emirates', 3030.00, 36360.00, 2.00, 6, 0, 5.00);
INSERT INTO public.employees VALUES (379, 'Ahmad', 'Alghurani', 'Male', '2020-09-18', 4, 'Manufacturing', 'United Arab Emirates', 2544.00, 30528.00, 5.00, 0, 0, 11.00);
INSERT INTO public.employees VALUES (380, 'Abd Alsamad', 'Ahmad', 'Male', '2017-02-12', 8, 'Facilities/Engineering', 'Egypt', 2872.00, 34464.00, 4.50, 5, 0, 7.00);
INSERT INTO public.employees VALUES (381, 'Amir', 'Alhasan', 'Male', '2019-01-03', 6, 'Product Development', 'Egypt', 2263.00, 27156.00, 4.50, 0, 0, 8.00);
INSERT INTO public.employees VALUES (382, 'Alaa', 'Altahhan', 'Female', '2019-08-27', 5, 'Quality Control', 'United Arab Emirates', 2136.00, 25632.00, 5.00, 4, 0, 12.00);
INSERT INTO public.employees VALUES (383, 'Iad', 'Mahfud', 'Male', '2017-07-24', 7, 'Manufacturing', 'Egypt', 2379.00, 28548.00, 4.50, 1, 0, 10.00);
INSERT INTO public.employees VALUES (384, 'Sarah', 'Damrani', 'Female', '2020-07-24', 4, 'Account Management', 'Egypt', 1940.00, 23280.00, 3.00, 4, 6, 5.00);
INSERT INTO public.employees VALUES (385, 'Husam', 'Aldubus', 'Male', '2019-05-18', 5, 'Facilities/Engineering', 'Egypt', 1558.00, 18696.00, 2.00, 0, 6, 9.00);
INSERT INTO public.employees VALUES (386, 'Ahmad', 'Zynu', 'Male', '2019-04-08', 6, 'IT', 'Egypt', 1341.00, 16092.00, 5.00, 3, 0, 8.00);
INSERT INTO public.employees VALUES (387, 'Lwy', 'Abu', 'Male', '2019-04-11', 6, 'Manufacturing', 'Egypt', 1703.00, 20436.00, 5.00, 2, 0, 10.00);
INSERT INTO public.employees VALUES (388, 'Tariq', 'Shams', 'Male', '2020-07-20', 4, 'Professional Training Group', 'Egypt', 3282.00, 39384.00, 1.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (389, 'Muhamad', 'Khalil', 'Male', '2020-03-05', 5, 'Sales', 'Egypt', 3125.00, 37500.00, 2.00, 6, 3, 0.00);
INSERT INTO public.employees VALUES (390, 'Amal', 'Alhusayn', 'Female', '2020-05-07', 5, 'Account Management', 'United Arab Emirates', 2232.00, 26784.00, 4.50, 0, 0, 7.00);
INSERT INTO public.employees VALUES (391, 'Fadi', 'Shakur', 'Male', '2017-03-29', 8, 'Quality Assurance', 'Syria', 2513.00, 30156.00, 4.50, 2, 0, 8.00);
INSERT INTO public.employees VALUES (392, 'Abdalhai', 'Sarhan', 'Male', '2017-02-22', 8, 'Facilities/Engineering', 'Syria', 2818.00, 33816.00, 2.00, 4, 0, 8.00);
INSERT INTO public.employees VALUES (393, 'Ahmad', 'Alqadi', 'Male', '2018-05-20', 6, 'Quality Assurance', 'Egypt', 2257.00, 27084.00, 3.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (394, 'Husam', 'Albush', 'Male', '2020-04-23', 5, 'Account Management', 'Egypt', 1265.00, 15180.00, 3.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (395, 'Anas', 'Eabidin', 'Male', '2020-10-26', 4, 'Manufacturing Admin', 'United Arab Emirates', 2207.00, 26484.00, 3.00, 2, 0, 0.00);
INSERT INTO public.employees VALUES (396, 'Muhamad', 'Ebdalwahd', 'Male', '2019-02-04', 6, 'Marketing', 'Egypt', 2806.00, 33672.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (397, 'Khalid', 'Iibrahim', 'Male', '2017-02-15', 8, 'Environmental Health/Safety', 'United Arab Emirates', 1521.00, 18252.00, 5.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (398, 'Muhamad', 'Aleazm', 'Male', '2018-04-07', 7, 'Facilities/Engineering', 'Egypt', 1867.00, 22404.00, 3.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (399, 'Maya', 'Alhmwi', 'Female', '2018-12-10', 6, 'Quality Control', 'Saudi Arabia', 2425.00, 29100.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (400, 'Basil', 'Khiat', 'Male', '2020-12-14', 4, 'Marketing', 'Saudi Arabia', 1758.00, 21096.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (401, 'Muhamad', 'Zaydan', 'Male', '2020-12-26', 4, 'Manufacturing', 'Syria', 2832.00, 33984.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (402, 'Randa', 'Alajw', 'Female', '2017-05-24', 7, 'Marketing', 'Egypt', 1371.00, 16452.00, 1.00, 1, 0, 8.00);
INSERT INTO public.employees VALUES (403, 'Muhamad', 'Alghazi', 'Male', '2018-12-27', 6, 'Marketing', 'Egypt', 2904.00, 34848.00, 5.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (404, 'Rahaf', 'Eijluni', 'Female', '2019-02-16', 6, 'Product Development', 'Lebanon', 3285.00, 39420.00, 3.00, 2, 0, 0.00);
INSERT INTO public.employees VALUES (405, 'Sultan', 'Alhijar', 'Male', '2018-07-09', 6, 'Facilities/Engineering', 'Egypt', 2964.00, 35568.00, 5.00, 2, 0, 45.00);
INSERT INTO public.employees VALUES (406, 'Asma', 'Sadqawi', 'Female', '2018-04-05', 7, 'Account Management', 'United Arab Emirates', 974.00, 11688.00, 2.00, 5, 0, 5.00);
INSERT INTO public.employees VALUES (407, 'Fulla', 'Alkhalid', 'Female', '2019-04-24', 6, 'Account Management', 'Saudi Arabia', 2607.00, 31284.00, 4.50, 0, 0, 9.00);
INSERT INTO public.employees VALUES (408, 'Lujin', 'Alaleppoy', 'Female', '2017-09-20', 7, 'Quality Control', 'Egypt', 1550.00, 18600.00, 1.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (409, 'Jihan', 'Alqudmani', 'Female', '2016-07-23', 8, 'Sales', 'Egypt', 1631.00, 19572.00, 4.50, 0, 0, 4.00);
INSERT INTO public.employees VALUES (410, 'Anwar', 'Alkhayran', 'Male', '2019-02-10', 6, 'Marketing', 'Egypt', 3003.00, 36036.00, 1.00, 6, 1, 6.00);
INSERT INTO public.employees VALUES (411, 'Qasim', 'Muhamad', 'Male', '2019-12-01', 5, 'Manufacturing', 'Egypt', 913.00, 10956.00, 5.00, 0, 0, 12.00);
INSERT INTO public.employees VALUES (412, 'Samir', 'Altaynawi', 'Male', '2017-07-18', 7, 'Facilities/Engineering', 'Egypt', 2076.00, 24912.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (413, 'Alaa', 'Hafiz', 'Female', '2020-06-26', 4, 'Facilities/Engineering', 'Egypt', 2749.00, 32988.00, 3.00, 5, 4, 0.00);
INSERT INTO public.employees VALUES (414, 'Kamilia', 'Sydu', 'Female', '2019-01-25', 6, 'IT', 'Saudi Arabia', 2617.00, 31404.00, 4.50, 1, 0, 5.00);
INSERT INTO public.employees VALUES (415, 'Ali', 'Marwan', 'Male', '2019-08-20', 5, 'IT', 'United Arab Emirates', 1680.00, 20160.00, 5.00, 1, 0, 35.00);
INSERT INTO public.employees VALUES (416, 'Mahir', 'Almarstani', 'Male', '2020-03-09', 5, 'Green Building', 'Egypt', 2824.00, 33888.00, 3.00, 3, 0, 3.00);
INSERT INTO public.employees VALUES (417, 'Rwad', 'Alddahir', 'Female', '2017-09-26', 7, 'Product Development', 'Egypt', 1646.00, 19752.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (418, 'Jury', 'Eabuwd', 'Female', '2018-12-04', 6, 'Quality Control', 'Egypt', 979.00, 11748.00, 5.00, 5, 0, 8.00);
INSERT INTO public.employees VALUES (419, 'Sayban', 'Musur', 'Female', '2019-01-02', 6, 'Quality Assurance', 'Syria', 1274.00, 15288.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (420, 'Diana', 'Muayid', 'Female', '2019-10-27', 5, 'Facilities/Engineering', 'Egypt', 2715.00, 32580.00, 2.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (421, 'Lbyb', 'Fahd', 'Male', '2019-11-12', 5, 'Manufacturing', 'Syria', 1158.00, 13896.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (422, 'Bashshar', 'Bilul', 'Male', '2018-08-02', 6, 'Marketing', 'Egypt', 1986.00, 23832.00, 3.00, 1, 0, 14.00);
INSERT INTO public.employees VALUES (423, 'Ali', 'Alnuwri', 'Male', '2019-12-27', 5, 'Manufacturing', 'Saudi Arabia', 3299.00, 39588.00, 5.00, 1, 0, 0.00);
INSERT INTO public.employees VALUES (424, 'Salim', 'Aleabd', 'Male', '2017-11-23', 7, 'Quality Control', 'Egypt', 2405.00, 28860.00, 5.00, 0, 0, 97.00);
INSERT INTO public.employees VALUES (425, 'Abd Alruhmin', 'Allaham', 'Male', '2020-07-15', 4, 'Facilities/Engineering', 'Egypt', 2205.00, 26460.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (426, 'Muhamad', 'Raft', 'Male', '2016-07-11', 8, 'Manufacturing', 'Egypt', 2651.00, 31812.00, 3.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (427, 'Ahmad', 'Shakir', 'Male', '2019-05-30', 5, 'Account Management', 'Egypt', 1693.00, 20316.00, 4.50, 2, 5, 6.00);
INSERT INTO public.employees VALUES (428, 'Rasha', 'Asead', 'Female', '2019-12-22', 5, 'Sales', 'Egypt', 1690.00, 20280.00, 1.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (429, 'Omar', 'Alwurhani', 'Male', '2019-02-03', 6, 'Account Management', 'Egypt', 766.00, 9192.00, 3.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (430, 'Ayham', 'Kharbutli', 'Male', '2019-07-15', 5, 'Research/Development', 'Egypt', 2542.00, 30504.00, 3.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (431, 'Sahar', 'Jaridiun', 'Female', '2016-10-11', 8, 'Professional Training Group', 'United Arab Emirates', 1966.00, 23592.00, 4.50, 0, 0, 8.00);
INSERT INTO public.employees VALUES (432, 'Muhamad', 'Tamur', 'Male', '2019-07-06', 5, 'Manufacturing', 'Egypt', 2977.00, 35724.00, 4.50, 0, 0, 8.00);
INSERT INTO public.employees VALUES (433, 'Ayham', 'Alkhlf', 'Male', '2017-11-04', 7, 'Quality Assurance', 'United Arab Emirates', 1404.00, 16848.00, 1.00, 5, 0, 10.00);
INSERT INTO public.employees VALUES (434, 'Emar', 'Eisaf', 'Female', '2018-02-05', 7, 'Quality Control', 'Syria', 1848.00, 22176.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (435, 'Iin', 'Bitahish', 'Female', '2020-09-08', 4, 'Manufacturing', 'Egypt', 2069.00, 24828.00, 3.00, 2, 5, 6.00);
INSERT INTO public.employees VALUES (436, 'Abdalrhim', 'Eimaruh', 'Male', '2020-10-18', 4, 'Quality Assurance', 'Saudi Arabia', 1072.00, 12864.00, 4.50, 0, 0, 6.00);
INSERT INTO public.employees VALUES (437, 'Bashaer', 'Hadalah', 'Female', '2019-12-14', 5, 'Product Development', 'Egypt', 1984.00, 23808.00, 1.00, 1, 0, 8.00);
INSERT INTO public.employees VALUES (438, 'Sana', 'Maeruf', 'Female', '2020-08-21', 4, 'Account Management', 'Egypt', 999.00, 11988.00, 1.00, 5, 0, 61.00);
INSERT INTO public.employees VALUES (439, 'Amir', 'Alnuwnu', 'Male', '2020-05-15', 4, 'Quality Control', 'Syria', 2915.00, 34980.00, 3.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (440, 'Salim', 'Albarghali', 'Male', '2019-11-01', 5, 'Facilities/Engineering', 'Egypt', 3158.00, 37896.00, 4.50, 3, 0, 7.00);
INSERT INTO public.employees VALUES (441, 'Iin', 'Murad', 'Female', '2017-08-30', 7, 'IT', 'Egypt', 711.00, 8532.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (442, 'Baha Aldiyn', 'Marzuq', 'Male', '2018-04-05', 7, 'Quality Control', 'Saudi Arabia', 899.00, 10788.00, 5.00, 6, 0, 38.00);
INSERT INTO public.employees VALUES (443, 'Abd Alruhmin', 'Hamj', 'Male', '2020-03-10', 5, 'Account Management', 'Egypt', 2571.00, 30852.00, 3.00, 1, 0, 6.00);
INSERT INTO public.employees VALUES (444, 'Ahmad', 'Bradey', 'Male', '2018-06-14', 6, 'Quality Control', 'Egypt', 2437.00, 29244.00, 5.00, 0, 4, 8.00);
INSERT INTO public.employees VALUES (445, 'Sabah', 'Qadish', 'Female', '2019-03-18', 6, 'Manufacturing', 'Egypt', 2453.00, 29436.00, 5.00, 1, 0, 6.00);
INSERT INTO public.employees VALUES (446, 'Asra', 'Almisri', 'Female', '2018-06-28', 6, 'Manufacturing', 'Egypt', 1839.00, 22068.00, 5.00, 1, 0, 9.00);
INSERT INTO public.employees VALUES (447, 'Faras', 'Kawaara', 'Male', '2017-02-21', 8, 'Quality Control', 'United Arab Emirates', 2306.00, 27672.00, 1.00, 6, 0, 7.00);
INSERT INTO public.employees VALUES (448, 'Muhamad', 'Abunfis', 'Male', '2018-06-18', 6, 'Product Development', 'Syria', 970.00, 11640.00, 1.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (449, 'Lawiy', 'Shiah', 'Male', '2018-05-04', 7, 'Quality Assurance', 'Egypt', 3140.00, 37680.00, 3.00, 6, 1, 5.00);
INSERT INTO public.employees VALUES (450, 'Rama', 'Alsaghir', 'Female', '2017-04-10', 8, 'Professional Training Group', 'Egypt', 1176.00, 14112.00, 5.00, 2, 0, 6.00);
INSERT INTO public.employees VALUES (451, 'Ahmad', 'Qadimati', 'Male', '2019-08-21', 5, 'Facilities/Engineering', 'United Arab Emirates', 2742.00, 32904.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (452, 'Qays', 'Dahna', 'Male', '2017-09-18', 7, 'Quality Control', 'Egypt', 734.00, 8808.00, 3.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (453, 'Raja', 'Eaziza', 'Male', '2018-02-02', 7, 'Manufacturing', 'Syria', 894.00, 10728.00, 3.00, 6, 0, 93.00);
INSERT INTO public.employees VALUES (454, 'Emar', 'Nakaash', 'Female', '2020-11-09', 4, 'Account Management', 'Saudi Arabia', 2640.00, 31680.00, 4.50, 1, 5, 4.00);
INSERT INTO public.employees VALUES (455, 'Ranya', 'Khuluf', 'Female', '2019-02-01', 6, 'Manufacturing', 'Egypt', 1059.00, 12708.00, 2.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (456, 'Kinda', 'Zaki', 'Female', '2018-06-09', 6, 'Product Development', 'Lebanon', 3337.00, 40044.00, 3.00, 0, 2, 6.00);
INSERT INTO public.employees VALUES (457, 'Muhamad', 'Asamh Tubae', 'Male', '2020-08-20', 4, 'Quality Assurance', 'Egypt', 3154.00, 37848.00, 3.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (458, 'Ahmad', 'Daeas', 'Male', '2019-02-12', 6, 'Facilities/Engineering', 'Egypt', 1618.00, 19416.00, 3.00, 1, 0, 1.00);
INSERT INTO public.employees VALUES (459, 'Muhamad', 'Shadi Alkhiat', 'Male', '2017-02-20', 8, 'Quality Assurance', 'United Arab Emirates', 1248.00, 14976.00, 5.00, 0, 6, 7.00);
INSERT INTO public.employees VALUES (460, 'Omaimah', 'Tqi Aldiyn', 'Female', '2017-08-31', 7, 'Quality Assurance', 'Egypt', 1523.00, 18276.00, 3.00, 6, 5, 4.00);
INSERT INTO public.employees VALUES (461, 'Tahani', 'Yasir', 'Female', '2019-01-10', 6, 'Manufacturing', 'Egypt', 1275.00, 15300.00, 4.50, 3, 0, 9.00);
INSERT INTO public.employees VALUES (462, 'Hasan', 'Alfywmi', 'Male', '2019-01-07', 6, 'Account Management', 'Syria', 1549.00, 18588.00, 3.00, 2, 0, 5.00);
INSERT INTO public.employees VALUES (463, 'Zahir', 'Zarie', 'Male', '2019-06-02', 5, 'Professional Training Group', 'Saudi Arabia', 1786.00, 21432.00, 3.00, 4, 4, 1.00);
INSERT INTO public.employees VALUES (464, 'Muhamad', 'Eaqad', 'Male', '2019-04-02', 6, 'Quality Assurance', 'Saudi Arabia', 1908.00, 22896.00, 1.00, 0, 5, 7.00);
INSERT INTO public.employees VALUES (465, 'Ahmad', 'Hamuwd', 'Male', '2018-05-29', 6, 'Facilities/Engineering', 'United Arab Emirates', 2321.00, 27852.00, 5.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (466, 'Ismaeil', 'Jdwe', 'Male', '2020-10-05', 4, 'Facilities/Engineering', 'United Arab Emirates', 899.00, 10788.00, 1.00, 4, 0, 27.00);
INSERT INTO public.employees VALUES (467, 'Muhamad', 'Saeid Alzarey', 'Male', '2019-12-23', 5, 'Professional Training Group', 'Egypt', 1168.00, 14016.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (468, 'Bakr', 'Eubdallah', 'Male', '2018-04-04', 7, 'Environmental Compliance', 'Egypt', 2169.00, 26028.00, 1.00, 4, 0, 2.00);
INSERT INTO public.employees VALUES (469, 'Muhamad', 'Basil', 'Male', '2020-03-10', 5, 'Human Resources', 'Lebanon', 2819.00, 33828.00, 4.50, 5, 0, 51.00);
INSERT INTO public.employees VALUES (470, 'Ahmad', 'Alnajar', 'Male', '2018-10-30', 6, 'IT', 'United Arab Emirates', 847.00, 10164.00, 3.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (471, 'Muhamad', 'Alsaman', 'Male', '2020-03-10', 5, 'Account Management', 'Egypt', 2308.00, 27696.00, 2.00, 0, 0, 13.00);
INSERT INTO public.employees VALUES (472, 'Lina', 'Wayly', 'Female', '2018-12-01', 6, 'Manufacturing', 'Egypt', 1692.00, 20304.00, 4.50, 4, 0, 6.00);
INSERT INTO public.employees VALUES (473, 'Raghid', 'Hutayniun', 'Male', '2018-02-28', 7, 'Quality Assurance', 'Egypt', 1372.00, 16464.00, 1.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (474, 'Ruba', 'Alsiraj', 'Female', '2019-06-01', 5, 'Account Management', 'Egypt', 2594.00, 31128.00, 3.00, 5, 0, 0.00);
INSERT INTO public.employees VALUES (475, 'Adnan', 'Allaadhiqanii', 'Male', '2018-05-17', 6, 'Quality Control', 'Egypt', 1082.00, 12984.00, 5.00, 1, 4, 8.00);
INSERT INTO public.employees VALUES (476, 'Muhamad', 'Shaeban', 'Male', '2018-11-09', 6, 'Manufacturing', 'Egypt', 1929.00, 23148.00, 5.00, 3, 0, 43.00);
INSERT INTO public.employees VALUES (477, 'Ghyath', 'Abu', 'Male', '2019-09-12', 5, 'Manufacturing', 'Saudi Arabia', 1883.00, 22596.00, 3.00, 3, 0, 3.00);
INSERT INTO public.employees VALUES (478, 'Basil', 'Farahat', 'Male', '2019-05-09', 6, 'Account Management', 'United Arab Emirates', 874.00, 10488.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (479, 'Khalid', 'Siriul', 'Male', '2016-08-21', 8, 'Quality Control', 'Saudi Arabia', 2780.00, 33360.00, 3.00, 3, 0, 2.00);
INSERT INTO public.employees VALUES (480, 'Salah Aldiyn', 'Salayk', 'Male', '2020-01-02', 5, 'IT', 'Syria', 1980.00, 23760.00, 2.00, 3, 0, 0.00);
INSERT INTO public.employees VALUES (481, 'Bilal', 'Einziin', 'Male', '2020-01-02', 5, 'Major Mfg Projects', 'Syria', 2611.00, 31332.00, 5.00, 4, 0, 9.00);
INSERT INTO public.employees VALUES (482, 'Abdalrhmin', 'Aljuju', 'Male', '2018-02-10', 7, 'Human Resources', 'Syria', 1881.00, 22572.00, 5.00, 1, 0, 1.00);
INSERT INTO public.employees VALUES (483, 'Lawy', 'Nadaf', 'Male', '2016-06-09', 8, 'Manufacturing', 'Egypt', 1517.00, 18204.00, 5.00, 4, 0, 6.00);
INSERT INTO public.employees VALUES (484, 'Ali', 'Muhamad', 'Male', '2019-12-26', 5, 'Product Development', 'Egypt', 1459.00, 17508.00, 4.50, 0, 0, 10.00);
INSERT INTO public.employees VALUES (485, 'Mahir', 'Bikar', 'Male', '2019-10-23', 5, 'Professional Training Group', 'Saudi Arabia', 2383.00, 28596.00, 3.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (486, 'Iad', 'Alhusayn', 'Male', '2018-03-09', 7, 'Quality Assurance', 'Egypt', 1420.00, 17040.00, 5.00, 2, 6, 7.00);
INSERT INTO public.employees VALUES (487, 'Husam', 'Ziada', 'Male', '2018-09-15', 6, 'Major Mfg Projects', 'Egypt', 1382.00, 16584.00, 4.50, 0, 1, 14.00);
INSERT INTO public.employees VALUES (488, 'Ahmad', 'Eashur', 'Male', '2020-09-23', 4, 'IT', 'United Arab Emirates', 1920.00, 23040.00, 5.00, 0, 5, 1.00);
INSERT INTO public.employees VALUES (489, 'Ahmad', 'Naqawuh', 'Male', '2020-09-17', 4, 'Quality Assurance', 'Egypt', 1202.00, 14424.00, 4.50, 0, 0, 92.00);
INSERT INTO public.employees VALUES (490, 'Tamadur', 'Barghuth', 'Female', '2018-02-25', 7, 'Marketing', 'Saudi Arabia', 1158.00, 13896.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (491, 'Diea', 'Jazar', 'Male', '2020-01-20', 5, 'Quality Control', 'Egypt', 1447.00, 17364.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (492, 'Bashshar', 'Mareiun', 'Male', '2019-09-23', 5, 'Sales', 'Saudi Arabia', 1598.00, 19176.00, 3.00, 0, 0, 95.00);
INSERT INTO public.employees VALUES (493, 'Abdaleziz', 'Eiwad', 'Male', '2020-05-23', 4, 'Quality Assurance', 'United Arab Emirates', 1714.00, 20568.00, 5.00, 6, 0, 11.00);
INSERT INTO public.employees VALUES (494, 'Amir', 'Alkhawam', 'Male', '2017-10-30', 7, 'Environmental Compliance', 'United Arab Emirates', 2994.00, 35928.00, 4.50, 1, 0, 4.00);
INSERT INTO public.employees VALUES (495, 'Alia', 'Maseud', 'Male', '2020-01-08', 5, 'Manufacturing', 'Saudi Arabia', 2125.00, 25500.00, 4.50, 6, 0, 6.00);
INSERT INTO public.employees VALUES (496, 'Asra', 'Abuhani', 'Female', '2019-01-28', 6, 'Quality Assurance', 'Egypt', 3059.00, 36708.00, 4.50, 5, 0, 9.00);
INSERT INTO public.employees VALUES (497, 'Ahmad', 'Alshamy', 'Male', '2019-01-17', 6, 'Account Management', 'United Arab Emirates', 2077.00, 24924.00, 5.00, 6, 0, 4.00);
INSERT INTO public.employees VALUES (498, 'Baha', 'Eusqul', 'Male', '2018-09-08', 6, 'Manufacturing', 'Egypt', 1962.00, 23544.00, 4.50, 6, 0, 10.00);
INSERT INTO public.employees VALUES (499, 'Muhamad', 'Hylmyh', 'Male', '2019-05-15', 5, 'IT', 'Egypt', 1573.00, 18876.00, 3.00, 6, 0, 2.00);
INSERT INTO public.employees VALUES (500, 'Khadijah', 'Turkamani', 'Female', '2019-06-26', 5, 'Account Management', 'Saudi Arabia', 882.00, 10584.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (501, 'Asra', 'Jameah', 'Female', '2018-10-25', 6, 'Manufacturing', 'Egypt', 1036.00, 12432.00, 5.00, 0, 6, 2.00);
INSERT INTO public.employees VALUES (502, 'Akram', 'Alhulwanii', 'Male', '2016-01-12', 9, 'IT', 'Egypt', 2790.00, 33480.00, 1.00, 1, 0, 8.00);
INSERT INTO public.employees VALUES (503, 'Samir', 'Almisri', 'Male', '2019-08-16', 5, 'Manufacturing', 'Egypt', 1951.00, 23412.00, 4.50, 1, 0, 8.00);
INSERT INTO public.employees VALUES (504, 'Ahmad', 'Iidris', 'Male', '2018-07-08', 6, 'Quality Control', 'Egypt', 2255.00, 27060.00, 5.00, 0, 4, 10.00);
INSERT INTO public.employees VALUES (505, 'Khawla', 'Dawi', 'Female', '2017-06-17', 7, 'Creative', 'Egypt', 3388.00, 40656.00, 3.00, 3, 0, 0.00);
INSERT INTO public.employees VALUES (506, 'Rayid', 'Zazana', 'Male', '2020-10-19', 4, 'Marketing', 'Egypt', 707.00, 8484.00, 2.00, 1, 0, 9.00);
INSERT INTO public.employees VALUES (507, 'Razan', 'Iybw', 'Female', '2020-06-14', 4, 'Environmental Compliance', 'Egypt', 1161.00, 13932.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (508, 'Jamil', 'Ghabur', 'Male', '2019-04-17', 6, 'Quality Control', 'United Arab Emirates', 1165.00, 13980.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (509, 'Alaa', 'Sultan', 'Female', '2019-03-18', 6, 'IT', 'United Arab Emirates', 1351.00, 16212.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (510, 'Sultan', 'Taysir', 'Male', '2016-10-06', 8, 'Product Development', 'Egypt', 1406.00, 16872.00, 3.00, 0, 3, 7.00);
INSERT INTO public.employees VALUES (511, 'Hanan', 'Kurdiun', 'Female', '2019-01-08', 6, 'Account Management', 'Saudi Arabia', 1699.00, 20388.00, 5.00, 0, 2, 5.00);
INSERT INTO public.employees VALUES (512, 'Basil', 'Salih', 'Male', '2017-11-04', 7, 'Facilities/Engineering', 'Egypt', 3007.00, 36084.00, 5.00, 0, 6, 11.00);
INSERT INTO public.employees VALUES (513, 'Rita', 'Dib', 'Female', '2020-06-26', 4, 'Product Development', 'Egypt', 879.00, 10548.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (514, 'Muhamad', 'Alghush', 'Male', '2019-05-01', 6, 'Quality Assurance', 'Lebanon', 2537.00, 30444.00, 2.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (515, 'Muhamad', 'Iismaeil', 'Male', '2020-11-15', 4, 'Account Management', 'Egypt', 2663.00, 31956.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (516, 'Khaldun', 'Alsaedi', 'Male', '2020-10-15', 4, 'Quality Control', 'Egypt', 2494.00, 29928.00, 4.50, 2, 0, 2.00);
INSERT INTO public.employees VALUES (517, 'Ghaliah', 'Eibad', 'Female', '2019-11-06', 5, 'Environmental Health/Safety', 'United Arab Emirates', 2585.00, 31020.00, 5.00, 1, 5, 7.00);
INSERT INTO public.employees VALUES (518, 'Muhamad', 'Alsaedi', 'Male', '2019-12-10', 5, 'Green Building', 'United Arab Emirates', 1776.00, 21312.00, 2.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (519, 'Eala', 'Zaniqa', 'Female', '2017-09-15', 7, 'Facilities/Engineering', 'Egypt', 3055.00, 36660.00, 3.00, 0, 4, 9.00);
INSERT INTO public.employees VALUES (520, 'Ayham', 'Sharfah', 'Male', '2018-01-13', 7, 'Manufacturing', 'Saudi Arabia', 1707.00, 20484.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (521, 'Ahmad', 'Kazeur', 'Male', '2019-06-27', 5, 'Facilities/Engineering', 'United Arab Emirates', 2719.00, 32628.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (522, 'Mujdi', 'Kiwan', 'Male', '2020-12-17', 4, 'Marketing', 'Egypt', 1715.00, 20580.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (523, 'Muhamad', 'Altynawi', 'Male', '2019-01-22', 6, 'Manufacturing', 'Egypt', 2181.00, 26172.00, 2.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (524, 'Lama', 'Alhasan', 'Female', '2017-12-17', 7, 'Manufacturing', 'United Arab Emirates', 1382.00, 16584.00, 5.00, 0, 4, 8.00);
INSERT INTO public.employees VALUES (525, 'Lama', 'Almisri', 'Female', '2020-05-06', 5, 'Manufacturing', 'Egypt', 3350.00, 40200.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (526, 'Thayir', 'Hamuwda', 'Male', '2020-05-09', 5, 'Facilities/Engineering', 'United Arab Emirates', 1710.00, 20520.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (527, 'Abdallah', 'Zakariaa', 'Male', '2019-05-08', 6, 'Manufacturing', 'United Arab Emirates', 2785.00, 33420.00, 1.00, 0, 4, 3.00);
INSERT INTO public.employees VALUES (528, 'Ikhlas', 'Alhasan', 'Female', '2019-11-15', 5, 'Human Resources', 'United Arab Emirates', 2425.00, 29100.00, 4.50, 0, 0, 10.00);
INSERT INTO public.employees VALUES (529, 'Muhamad', 'Jzayrly', 'Male', '2018-07-28', 6, 'Marketing', 'Egypt', 1117.00, 13404.00, 3.00, 3, 0, 8.00);
INSERT INTO public.employees VALUES (530, 'Husam', 'Badr', 'Male', '2019-04-27', 6, 'Account Management', 'Egypt', 1112.00, 13344.00, 5.00, 1, 6, 40.00);
INSERT INTO public.employees VALUES (531, 'Rami', 'Hunun', 'Male', '2020-04-23', 5, 'Marketing', 'Egypt', 1928.00, 23136.00, 4.50, 6, 0, 1.00);
INSERT INTO public.employees VALUES (532, 'Alia', 'Abu', 'Female', '2018-11-06', 6, 'Facilities/Engineering', 'Saudi Arabia', 3300.00, 39600.00, 5.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (533, 'Samir', 'Sariji', 'Male', '2020-07-15', 4, 'Marketing', 'Egypt', 2378.00, 28536.00, 5.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (534, 'Muhamad', 'Albieli', 'Male', '2016-06-26', 8, 'Quality Control', 'United Arab Emirates', 3138.00, 37656.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (535, 'Ahmad', 'Eyd Bndqjy', 'Male', '2017-07-29', 7, 'Manufacturing', 'United Arab Emirates', 1981.00, 23772.00, 5.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (536, 'Maria', 'Lulu', 'Female', '2018-06-14', 6, 'Manufacturing', 'Saudi Arabia', 1056.00, 12672.00, 3.00, 0, 0, 94.00);
INSERT INTO public.employees VALUES (537, 'Muhamad', 'Shhybr', 'Male', '2019-12-31', 5, 'Facilities/Engineering', 'Egypt', 3295.00, 39540.00, 5.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (538, 'Abdalbasit', 'Aljazayiriu', 'Male', '2019-10-08', 5, 'Facilities/Engineering', 'Egypt', 1022.00, 12264.00, 4.50, 1, 0, 2.00);
INSERT INTO public.employees VALUES (539, 'Bilal', 'Aywbi', 'Male', '2020-10-21', 4, 'Green Building', 'United Arab Emirates', 969.00, 11628.00, 3.00, 1, 0, 0.00);
INSERT INTO public.employees VALUES (540, 'Ahmad', 'Dabana', 'Male', '2019-04-13', 6, 'Environmental Compliance', 'Egypt', 3354.00, 40248.00, 4.50, 3, 0, 1.00);
INSERT INTO public.employees VALUES (541, 'Fawaz', 'Ghazal', 'Male', '2020-01-21', 5, 'Quality Control', 'Egypt', 2123.00, 25476.00, 5.00, 0, 0, 15.00);
INSERT INTO public.employees VALUES (542, 'Bisam', 'Altahhan', 'Female', '2019-09-20', 5, 'Facilities/Engineering', 'Egypt', 897.00, 10764.00, 3.00, 2, 0, 11.00);
INSERT INTO public.employees VALUES (543, 'Muhamad', 'Amir', 'Male', '2018-04-17', 7, 'Quality Control', 'Saudi Arabia', 2925.00, 35100.00, 3.00, 3, 0, 14.00);
INSERT INTO public.employees VALUES (544, 'Lilas', 'Nafae', 'Female', '2018-09-05', 6, 'Quality Control', 'Egypt', 1895.00, 22740.00, 2.00, 0, 5, 81.00);
INSERT INTO public.employees VALUES (545, 'Muhamad', 'Ayman', 'Male', '2016-02-09', 9, 'Environmental Health/Safety', 'Egypt', 2191.00, 26292.00, 5.00, 2, 0, 7.00);
INSERT INTO public.employees VALUES (546, 'Ranim', 'Earabi', 'Female', '2020-02-29', 5, 'Research/Development', 'Egypt', 3130.00, 37560.00, 3.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (547, 'Amani', 'Altujjar', 'Female', '2016-11-21', 8, 'Product Development', 'Egypt', 2654.00, 31848.00, 3.00, 0, 1, 7.00);
INSERT INTO public.employees VALUES (548, 'Muhamad', 'Rashid', 'Male', '2020-12-27', 4, 'Quality Control', 'Saudi Arabia', 859.00, 10308.00, 5.00, 0, 1, 5.00);
INSERT INTO public.employees VALUES (549, 'Amin', 'Hamid', 'Male', '2016-06-16', 8, 'Quality Assurance', 'Egypt', 1113.00, 13356.00, 3.00, 4, 0, 11.00);
INSERT INTO public.employees VALUES (550, 'Khalid', 'Jameah', 'Male', '2019-09-17', 5, 'Account Management', 'Egypt', 1234.00, 14808.00, 5.00, 1, 5, 10.00);
INSERT INTO public.employees VALUES (551, 'Fahd', 'Shaykh', 'Male', '2019-12-16', 5, 'Marketing', 'Egypt', 2647.00, 31764.00, 3.00, 4, 0, 1.00);
INSERT INTO public.employees VALUES (552, 'Lilas', 'Kashik', 'Female', '2016-08-01', 8, 'Green Building', 'Saudi Arabia', 2200.00, 26400.00, 1.00, 1, 0, 6.00);
INSERT INTO public.employees VALUES (553, 'Fatima', 'Hasan', 'Female', '2018-03-24', 7, 'Major Mfg Projects', 'Egypt', 2381.00, 28572.00, 4.50, 2, 0, 10.00);
INSERT INTO public.employees VALUES (554, 'Diea', 'Dakhal', 'Male', '2019-12-18', 5, 'Account Management', 'United Arab Emirates', 2329.00, 27948.00, 2.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (555, 'Amir', 'Karishati', 'Male', '2019-07-30', 5, 'Manufacturing', 'Egypt', 1075.00, 12900.00, 3.00, 0, 4, 61.00);
INSERT INTO public.employees VALUES (556, 'Madlin', 'Alsaed', 'Female', '2017-10-05', 7, 'Marketing', 'Egypt', 3110.00, 37320.00, 1.00, 1, 4, 1.00);
INSERT INTO public.employees VALUES (557, 'Adnan', 'Aleaqla', 'Male', '2017-05-23', 7, 'Manufacturing', 'Egypt', 2777.00, 33324.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (558, 'Muhamad', 'Eursaly', 'Male', '2019-03-01', 6, 'Training', 'Egypt', 2306.00, 27672.00, 2.00, 5, 5, 11.00);
INSERT INTO public.employees VALUES (559, 'Ranya', 'Alaishhab', 'Female', '2016-12-18', 8, 'Quality Assurance', 'Egypt', 1213.00, 14556.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (560, 'Rulaa', 'Shannar', 'Female', '2020-04-19', 5, 'Quality Assurance', 'Egypt', 2680.00, 32160.00, 4.50, 0, 0, 1.00);
INSERT INTO public.employees VALUES (561, 'Aynas', 'Alhiwat', 'Female', '2020-11-17', 4, 'Quality Assurance', 'Egypt', 2204.00, 26448.00, 4.50, 1, 0, 4.00);
INSERT INTO public.employees VALUES (562, 'Sara', 'Tabanaj', 'Female', '2018-01-13', 7, 'Manufacturing', 'Egypt', 1297.00, 15564.00, 2.00, 2, 0, 8.00);
INSERT INTO public.employees VALUES (563, 'Abd Allah', 'Aldahan', 'Male', '2020-12-14', 4, 'Quality Control', 'Egypt', 3024.00, 36288.00, 4.50, 6, 1, 48.00);
INSERT INTO public.employees VALUES (564, 'Muhamad', 'Ramzi', 'Male', '2018-02-11', 7, 'Creative', 'Egypt', 2228.00, 26736.00, 5.00, 1, 0, 78.00);
INSERT INTO public.employees VALUES (565, 'Jan', 'Mikayiylian', 'Male', '2016-01-08', 9, 'Quality Assurance', 'Egypt', 2009.00, 24108.00, 4.50, 6, 0, 0.00);
INSERT INTO public.employees VALUES (566, 'Almuthanaa', 'Alsaediu', 'Male', '2020-09-13', 4, 'Account Management', 'Egypt', 2573.00, 30876.00, 5.00, 0, 0, 28.00);
INSERT INTO public.employees VALUES (567, 'Emad', 'Dulul', 'Male', '2018-04-04', 7, 'Manufacturing', 'Egypt', 1938.00, 23256.00, 3.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (568, 'Sarah', 'Haydar', 'Female', '2019-07-17', 5, 'Account Management', 'Egypt', 1208.00, 14496.00, 5.00, 3, 0, 10.00);
INSERT INTO public.employees VALUES (569, 'Abdalkarim', 'Shueayb', 'Male', '2019-07-17', 5, 'Manufacturing Admin', 'Syria', 2342.00, 28104.00, 4.50, 5, 0, 10.00);
INSERT INTO public.employees VALUES (570, 'Muhamad', 'Khayr', 'Male', '2020-04-29', 5, 'IT', 'Egypt', 3244.00, 38928.00, 4.50, 0, 0, 78.00);
INSERT INTO public.employees VALUES (571, 'Shadi', 'Qitan', 'Male', '2017-04-04', 8, 'Account Management', 'Egypt', 2613.00, 31356.00, 4.50, 0, 1, 5.00);
INSERT INTO public.employees VALUES (572, 'Muhamad', 'Rajab', 'Male', '2020-12-19', 4, 'Manufacturing', 'Saudi Arabia', 2263.00, 27156.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (573, 'Khalid', 'Alkhawam', 'Male', '2016-07-06', 8, 'Account Management', 'Egypt', 3157.00, 37884.00, 5.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (574, 'Muhamad', 'Asamh', 'Male', '2018-03-07', 7, 'Account Management', 'Syria', 2519.00, 30228.00, 5.00, 2, 2, 10.00);
INSERT INTO public.employees VALUES (575, 'Alaa', 'Alyusif', 'Female', '2020-03-04', 5, 'IT', 'United Arab Emirates', 3019.00, 36228.00, 4.50, 2, 0, 15.00);
INSERT INTO public.employees VALUES (576, 'Asym', 'Aleaqqad', 'Female', '2019-04-22', 6, 'Manufacturing', 'United Arab Emirates', 3048.00, 36576.00, 2.00, 3, 6, 6.00);
INSERT INTO public.employees VALUES (577, 'Ahmad', 'Dahman', 'Male', '2019-12-12', 5, 'Manufacturing', 'Egypt', 1523.00, 18276.00, 4.50, 0, 4, 2.00);
INSERT INTO public.employees VALUES (578, 'Oqba', 'Alqintar', 'Male', '2019-02-09', 6, 'Marketing', 'Egypt', 2197.00, 26364.00, 1.00, 1, 0, 8.00);
INSERT INTO public.employees VALUES (579, 'Rahaf', 'Laylanaan', 'Female', '2019-04-01', 6, 'Product Development', 'Egypt', 1870.00, 22440.00, 4.50, 0, 3, 15.00);
INSERT INTO public.employees VALUES (580, 'Muhamad', 'Rajab', 'Male', '2018-03-17', 7, 'Manufacturing', 'United Arab Emirates', 1058.00, 12696.00, 5.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (581, 'Ramadan', 'Muhii Aldiyn', 'Male', '2019-10-03', 5, 'Sales', 'Egypt', 1257.00, 15084.00, 4.50, 1, 3, 2.00);
INSERT INTO public.employees VALUES (582, 'Zaynab', 'Eirat', 'Female', '2019-12-26', 5, 'Product Development', 'United Arab Emirates', 819.00, 9828.00, 4.50, 5, 0, 7.00);
INSERT INTO public.employees VALUES (583, 'Salah Aldiyn', 'Altibae', 'Male', '2019-11-06', 5, 'Research Center', 'United Arab Emirates', 3068.00, 36816.00, 2.00, 4, 0, 8.00);
INSERT INTO public.employees VALUES (584, 'Faras', 'Alghandur', 'Male', '2019-09-25', 5, 'IT', 'Syria', 1814.00, 21768.00, 3.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (585, 'Husam', 'Tamim', 'Male', '2019-05-20', 5, 'Quality Control', 'Egypt', 1076.00, 12912.00, 5.00, 1, 0, 4.00);
INSERT INTO public.employees VALUES (586, 'Ayat', 'Byd', 'Female', '2017-01-01', 8, 'Environmental Health/Safety', 'Egypt', 3120.00, 37440.00, 3.00, 3, 0, 2.00);
INSERT INTO public.employees VALUES (587, 'Rima', 'Daly', 'Female', '2020-08-29', 4, 'Quality Control', 'Egypt', 1359.00, 16308.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (588, 'Muhamad', 'Almunajid', 'Male', '2020-01-04', 5, 'Manufacturing', 'Egypt', 3391.00, 40692.00, 1.00, 0, 3, 1.00);
INSERT INTO public.employees VALUES (589, 'Eynas', 'Muhamad', 'Female', '2020-08-11', 4, 'IT', 'Syria', 1892.00, 22704.00, 5.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (590, 'Ahmad', 'Ahmid', 'Male', '2020-02-23', 5, 'Manufacturing', 'Egypt', 2639.00, 31668.00, 1.00, 1, 0, 3.00);
INSERT INTO public.employees VALUES (591, 'Madlin', 'Aljabaei', 'Female', '2020-07-27', 4, 'Facilities/Engineering', 'Egypt', 1580.00, 18960.00, 5.00, 2, 5, 6.00);
INSERT INTO public.employees VALUES (592, 'Ali', 'Alqadri', 'Male', '2019-08-15', 5, 'Quality Control', 'Egypt', 2186.00, 26232.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (593, 'Muhamad', 'Dib', 'Male', '2019-08-07', 5, 'Facilities/Engineering', 'United Arab Emirates', 1574.00, 18888.00, 2.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (594, 'Hanan', 'Bradiei', 'Female', '2018-02-23', 7, 'Account Management', 'Saudi Arabia', 2013.00, 24156.00, 4.50, 6, 0, 8.00);
INSERT INTO public.employees VALUES (595, 'Danah', 'Suirkili', 'Female', '2020-01-05', 5, 'IT', 'Egypt', 2075.00, 24900.00, 2.00, 0, 0, 5.00);
INSERT INTO public.employees VALUES (596, 'Ghada', 'Darakal', 'Female', '2018-05-05', 7, 'Manufacturing', 'Egypt', 1372.00, 16464.00, 1.00, 0, 3, 2.00);
INSERT INTO public.employees VALUES (597, 'Mazin', 'Bihtiti', 'Male', '2018-08-03', 6, 'Facilities/Engineering', 'Egypt', 2026.00, 24312.00, 4.50, 0, 0, 7.00);
INSERT INTO public.employees VALUES (598, 'Ridwan', 'Alshulyan', 'Male', '2017-04-29', 8, 'Manufacturing', 'United Arab Emirates', 1351.00, 16212.00, 2.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (599, 'Ali', 'Barghaly', 'Male', '2017-05-29', 7, 'Quality Control', 'Egypt', 1111.00, 13332.00, 1.00, 3, 0, 6.00);
INSERT INTO public.employees VALUES (600, 'Iad', 'Badran', 'Male', '2020-07-04', 4, 'Quality Control', 'Egypt', 1554.00, 18648.00, 5.00, 6, 5, 8.00);
INSERT INTO public.employees VALUES (601, 'Abdalrhmin', 'Shwk', 'Male', '2019-10-20', 5, 'Quality Assurance', 'Saudi Arabia', 3057.00, 36684.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (602, 'Husam', 'Aldiyn', 'Male', '2018-12-19', 6, 'IT', 'Saudi Arabia', 1733.00, 20796.00, 3.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (603, 'Ahmad', 'Hamuwdatan', 'Male', '2016-01-24', 9, 'Environmental Health/Safety', 'Egypt', 1511.00, 18132.00, 5.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (604, 'Ahmad', 'Laylana', 'Male', '2017-01-02', 8, 'Sales', 'Egypt', 2542.00, 30504.00, 5.00, 0, 6, 6.00);
INSERT INTO public.employees VALUES (605, 'Shuruq', 'Aljuju', 'Female', '2019-12-31', 5, 'Quality Control', 'Egypt', 1573.00, 18876.00, 1.00, 2, 0, 3.00);
INSERT INTO public.employees VALUES (606, 'Muhamad', 'Alshahrur', 'Male', '2017-10-02', 7, 'Manufacturing', 'Syria', 2604.00, 31248.00, 3.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (607, 'Rafif', 'Khalf', 'Female', '2019-05-07', 6, 'Quality Assurance', 'Syria', 3152.00, 37824.00, 5.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (608, 'Muhamad', 'Alkhatib', 'Male', '2020-09-23', 4, 'Account Management', 'United Arab Emirates', 2655.00, 31860.00, 5.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (609, 'Muhamad', 'Albarnawi', 'Male', '2016-02-12', 9, 'Manufacturing Admin', 'Egypt', 1405.00, 16860.00, 5.00, 6, 0, 10.00);
INSERT INTO public.employees VALUES (610, 'Ali', 'Almiqdad', 'Male', '2018-05-14', 6, 'Manufacturing', 'Egypt', 3100.00, 37200.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (611, 'Ranya', 'Faris', 'Female', '2017-07-31', 7, 'Manufacturing', 'United Arab Emirates', 2729.00, 32748.00, 4.50, 0, 0, 6.00);
INSERT INTO public.employees VALUES (612, 'Ali', 'Alshaykh', 'Male', '2018-07-09', 6, 'Marketing', 'Egypt', 1467.00, 17604.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (613, 'Iin', 'Kafa', 'Female', '2017-02-25', 8, 'Manufacturing', 'Saudi Arabia', 1612.00, 19344.00, 5.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (614, 'Muhamad', 'Almaghribi', 'Male', '2019-04-19', 6, 'Quality Control', 'Egypt', 2901.00, 34812.00, 5.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (615, 'Sami', 'Aldrwysh', 'Male', '2017-08-05', 7, 'Environmental Health/Safety', 'Egypt', 1999.00, 23988.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (616, 'Samah', 'Alkhatib', 'Female', '2018-05-19', 6, 'Account Management', 'Saudi Arabia', 705.00, 8460.00, 3.00, 6, 0, 8.00);
INSERT INTO public.employees VALUES (617, 'Eala', 'Hatim', 'Female', '2019-09-29', 5, 'Sales', 'Egypt', 3311.00, 39732.00, 4.50, 0, 0, 1.00);
INSERT INTO public.employees VALUES (618, 'Dalia', 'Nahlawi', 'Female', '2018-01-07', 7, 'Manufacturing', 'Egypt', 2516.00, 30192.00, 3.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (619, 'Rabye''', 'Alzrqawy', 'Male', '2019-10-04', 5, 'Account Management', 'Saudi Arabia', 2000.00, 24000.00, 3.00, 1, 0, 0.00);
INSERT INTO public.employees VALUES (620, 'Kholoud', 'Huquq', 'Female', '2019-09-27', 5, 'Facilities/Engineering', 'United Arab Emirates', 2860.00, 34320.00, 3.00, 0, 6, 7.00);
INSERT INTO public.employees VALUES (621, 'Ibrahim', 'Alqatish', 'Male', '2019-04-02', 6, 'Quality Control', 'Egypt', 943.00, 11316.00, 4.50, 0, 0, 1.00);
INSERT INTO public.employees VALUES (622, 'Salih', 'Altawil', 'Male', '2019-09-12', 5, 'Quality Control', 'Syria', 1018.00, 12216.00, 2.00, 5, 0, 10.00);
INSERT INTO public.employees VALUES (623, 'Sami', 'Alsyd Ahmad', 'Male', '2019-02-06', 6, 'Quality Control', 'Egypt', 1835.00, 22020.00, 3.00, 1, 0, 50.00);
INSERT INTO public.employees VALUES (624, 'Zahir', 'Aleitar', 'Male', '2018-09-05', 6, 'Quality Assurance', 'Syria', 2192.00, 26304.00, 4.50, 0, 4, 1.00);
INSERT INTO public.employees VALUES (625, 'Fatir', 'Alealiu', 'Male', '2019-06-25', 5, 'Manufacturing', 'Egypt', 2875.00, 34500.00, 3.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (626, 'Samir', 'Alealiu', 'Male', '2019-09-29', 5, 'Marketing', 'Saudi Arabia', 1332.00, 15984.00, 2.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (627, 'Muhamad', 'Sulayman', 'Male', '2017-12-02', 7, 'IT', 'Saudi Arabia', 2023.00, 24276.00, 5.00, 6, 0, 5.00);
INSERT INTO public.employees VALUES (628, 'Muhamad', 'Suqabani', 'Male', '2020-11-21', 4, 'Quality Assurance', 'Egypt', 2094.00, 25128.00, 4.50, 6, 5, 2.00);
INSERT INTO public.employees VALUES (629, 'Muhamad', 'Aldubbas', 'Male', '2019-06-01', 5, 'Green Building', 'Saudi Arabia', 3006.00, 36072.00, 4.50, 0, 3, 7.00);
INSERT INTO public.employees VALUES (630, 'Hamzaa', 'Astitih', 'Male', '2019-11-26', 5, 'Manufacturing', 'United Arab Emirates', 2717.00, 32604.00, 5.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (631, 'Sulayman', 'Zinu', 'Male', '2018-08-14', 6, 'Training', 'United Arab Emirates', 3135.00, 37620.00, 3.00, 1, 0, 5.00);
INSERT INTO public.employees VALUES (632, 'Alaa', 'Alrifaei', 'Female', '2019-11-07', 5, 'Account Management', 'United Arab Emirates', 2334.00, 28008.00, 1.00, 2, 0, 2.00);
INSERT INTO public.employees VALUES (633, 'Rasha', 'Alrifaei', 'Female', '2019-01-22', 6, 'Account Management', 'Egypt', 1661.00, 19932.00, 5.00, 4, 0, 9.00);
INSERT INTO public.employees VALUES (634, 'Bayan', 'Darbika', 'Female', '2019-05-10', 6, 'Research Center', 'Egypt', 1230.00, 14760.00, 5.00, 0, 6, 5.00);
INSERT INTO public.employees VALUES (635, 'Iin', 'Almunzilijiu', 'Female', '2016-03-05', 9, 'Sales', 'Saudi Arabia', 1483.00, 17796.00, 5.00, 0, 2, 8.00);
INSERT INTO public.employees VALUES (636, 'Abd Alwahhab', 'Aldhiyab', 'Male', '2019-05-29', 5, 'Quality Control', 'United Arab Emirates', 2462.00, 29544.00, 3.00, 6, 3, 2.00);
INSERT INTO public.employees VALUES (637, 'Hanan', 'Salahi', 'Female', '2020-12-29', 4, 'Quality Assurance', 'Egypt', 2180.00, 26160.00, 5.00, 3, 0, 0.00);
INSERT INTO public.employees VALUES (638, 'Mari', 'Ayuwb', 'Female', '2016-07-25', 8, 'Creative', 'Egypt', 943.00, 11316.00, 5.00, 0, 4, 7.00);
INSERT INTO public.employees VALUES (639, 'Omar', 'Shawqi', 'Male', '2019-08-11', 5, 'Major Mfg Projects', 'Egypt', 2489.00, 29868.00, 3.00, 6, 0, 3.00);
INSERT INTO public.employees VALUES (640, 'Tariq', 'Aldhahabi', 'Male', '2019-11-12', 5, 'Product Development', 'Egypt', 2279.00, 27348.00, 5.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (641, 'Rama', 'Asead', 'Female', '2019-01-14', 6, 'Quality Assurance', 'Saudi Arabia', 840.00, 10080.00, 3.00, 4, 0, 10.00);
INSERT INTO public.employees VALUES (642, 'Ghayth', 'Eali', 'Male', '2019-02-15', 6, 'Quality Control', 'Egypt', 1601.00, 19212.00, 5.00, 0, 0, 3.00);
INSERT INTO public.employees VALUES (643, 'Mahir', 'Eabuwd', 'Male', '2018-04-28', 7, 'Account Management', 'Egypt', 1414.00, 16968.00, 5.00, 4, 0, 10.00);
INSERT INTO public.employees VALUES (644, 'Muwmin', 'Almujahid', 'Male', '2020-03-25', 5, 'IT', 'United Arab Emirates', 905.00, 10860.00, 3.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (645, 'Dima', 'Drwysh', 'Female', '2020-03-04', 5, 'Facilities/Engineering', 'United Arab Emirates', 2525.00, 30300.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (646, 'Muhamad', 'Khalid', 'Male', '2018-05-25', 6, 'Sales', 'Egypt', 1412.00, 16944.00, 2.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (647, 'Diea', 'Filyun', 'Male', '2020-01-04', 5, 'Manufacturing', 'Syria', 2397.00, 28764.00, 3.00, 0, 0, 100.00);
INSERT INTO public.employees VALUES (648, 'Muhamad', 'Tasbihji', 'Male', '2020-08-12', 4, 'Account Management', 'Egypt', 1153.00, 13836.00, 4.50, 0, 2, 10.00);
INSERT INTO public.employees VALUES (649, 'Mazin', 'Shumut', 'Male', '2017-08-05', 7, 'Account Management', 'Egypt', 2091.00, 25092.00, 2.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (650, 'Omar', 'Zaqzuq', 'Male', '2020-06-29', 4, 'Manufacturing', 'United Arab Emirates', 1444.00, 17328.00, 5.00, 3, 0, 7.00);
INSERT INTO public.employees VALUES (651, 'Yasmin', 'Eamir', 'Female', '2017-03-01', 8, 'Manufacturing', 'Egypt', 2360.00, 28320.00, 4.50, 0, 0, 1.00);
INSERT INTO public.employees VALUES (652, 'Muhamad', 'Haydar', 'Male', '2020-12-12', 4, 'Facilities/Engineering', 'United Arab Emirates', 2576.00, 30912.00, 1.00, 6, 0, 6.00);
INSERT INTO public.employees VALUES (653, 'Muhamad', 'Ratib', 'Male', '2019-11-24', 5, 'Account Management', 'Egypt', 2376.00, 28512.00, 2.00, 6, 0, 57.00);
INSERT INTO public.employees VALUES (654, 'Muayid', 'Siedih', 'Male', '2019-08-04', 5, 'Facilities/Engineering', 'United Arab Emirates', 2924.00, 35088.00, 4.50, 0, 0, 10.00);
INSERT INTO public.employees VALUES (655, 'Husam', 'Alhamd', 'Male', '2017-02-19', 8, 'Quality Assurance', 'Saudi Arabia', 2548.00, 30576.00, 1.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (656, 'Abdalkrim', 'Fadal', 'Male', '2020-01-22', 5, 'Account Management', 'Saudi Arabia', 841.00, 10092.00, 1.00, 4, 0, 7.00);
INSERT INTO public.employees VALUES (657, 'Bayan', 'Eurnus', 'Female', '2020-05-15', 4, 'Manufacturing', 'Egypt', 3017.00, 36204.00, 3.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (658, 'Abd Almueiyn', 'Eitaya', 'Male', '2018-01-26', 7, 'Facilities/Engineering', 'United Arab Emirates', 1077.00, 12924.00, 5.00, 0, 0, 9.00);
INSERT INTO public.employees VALUES (659, 'Sahar', 'Qisam', 'Female', '2018-05-03', 7, 'Marketing', 'Egypt', 3316.00, 39792.00, 4.50, 0, 0, 8.00);
INSERT INTO public.employees VALUES (660, 'Rafat', 'Musaa', 'Male', '2018-12-08', 6, 'Creative', 'Syria', 2188.00, 26256.00, 4.50, 5, 0, 9.00);
INSERT INTO public.employees VALUES (661, 'Shafiq', 'Almalih', 'Male', '2019-02-04', 6, 'Creative', 'United Arab Emirates', 1684.00, 20208.00, 5.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (662, 'Raghad', 'Aghasi', 'Female', '2019-11-14', 5, 'Account Management', 'Egypt', 716.00, 8592.00, 3.00, 0, 0, 8.00);
INSERT INTO public.employees VALUES (663, 'Ruba', 'Alhumwi', 'Female', '2019-05-19', 5, 'Manufacturing', 'Egypt', 2703.00, 32436.00, 2.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (664, 'Bilal', 'Alqalish', 'Male', '2018-07-08', 6, 'Manufacturing Admin', 'Egypt', 2361.00, 28332.00, 5.00, 0, 0, 1.00);
INSERT INTO public.employees VALUES (665, 'Muhamad', 'Almisri', 'Male', '2020-11-06', 4, 'Manufacturing', 'Egypt', 1797.00, 21564.00, 1.00, 6, 0, 7.00);
INSERT INTO public.employees VALUES (666, 'Husayn', 'Hawria', 'Male', '2020-06-13', 4, 'Environmental Compliance', 'Egypt', 2252.00, 27024.00, 3.00, 0, 0, 2.00);
INSERT INTO public.employees VALUES (667, 'Safa', 'Alshahadat', 'Female', '2018-09-30', 6, 'Manufacturing', 'Egypt', 2486.00, 29832.00, 5.00, 5, 2, 9.00);
INSERT INTO public.employees VALUES (668, 'Ahmad', 'Aldiyk', 'Male', '2020-06-13', 4, 'Manufacturing', 'Egypt', 1197.00, 14364.00, 2.00, 4, 0, 8.00);
INSERT INTO public.employees VALUES (669, 'Hind', 'Almueasaeas', 'Female', '2019-05-05', 6, 'Facilities/Engineering', 'Saudi Arabia', 3389.00, 40668.00, 3.00, 1, 0, 7.00);
INSERT INTO public.employees VALUES (670, 'Dania', 'Earmush', 'Female', '2019-12-01', 5, 'Product Development', 'United Arab Emirates', 2760.00, 33120.00, 1.00, 6, 6, 1.00);
INSERT INTO public.employees VALUES (671, 'Ayly', 'Bahriin', 'Male', '2017-09-14', 7, 'Professional Training Group', 'Saudi Arabia', 1232.00, 14784.00, 5.00, 3, 0, 10.00);
INSERT INTO public.employees VALUES (672, 'Jihan', 'Nadir', 'Female', '2019-04-18', 6, 'Facilities/Engineering', 'United Arab Emirates', 1045.00, 12540.00, 5.00, 6, 0, 4.00);
INSERT INTO public.employees VALUES (673, 'Muhamad', 'Sharif Aldaghly', 'Male', '2018-01-04', 7, 'IT', 'Egypt', 3257.00, 39084.00, 3.00, 0, 0, 6.00);
INSERT INTO public.employees VALUES (674, 'Emara', 'bwalsibae', 'Female', '2018-03-01', 7, 'Facilities/Engineering', 'Egypt', 3026.00, 36312.00, 3.00, 4, 0, 1.00);
INSERT INTO public.employees VALUES (675, 'Razzan', 'Alhusayni', 'Female', '2019-10-28', 5, 'Quality Assurance', 'Egypt', 1898.00, 22776.00, 4.50, 1, 0, 2.00);
INSERT INTO public.employees VALUES (676, 'Ghassan', 'Aljamal', 'Male', '2018-06-24', 6, 'Manufacturing', 'Egypt', 2778.00, 33336.00, 3.00, 2, 0, 20.00);
INSERT INTO public.employees VALUES (677, 'Omar', 'Kahulus', 'Male', '2018-01-04', 7, 'Quality Assurance', 'Syria', 2880.00, 34560.00, 2.00, 4, 0, 5.00);
INSERT INTO public.employees VALUES (678, 'Amjad', 'Nasir', 'Male', '2019-03-14', 6, 'Research Center', 'Saudi Arabia', 2815.00, 33780.00, 3.00, 6, 0, 2.00);
INSERT INTO public.employees VALUES (679, 'Iman', 'Ghrz Aldiyn', 'Female', '2018-12-14', 6, 'Green Building', 'Syria', 1134.00, 13608.00, 2.00, 0, 0, 14.00);
INSERT INTO public.employees VALUES (680, 'Alysia', 'Alyaghshiu', 'Female', '2019-10-19', 5, 'Training', 'United Arab Emirates', 3334.00, 40008.00, 1.00, 0, 0, 4.00);
INSERT INTO public.employees VALUES (681, 'Ayham', 'Alqadi', 'Male', '2020-05-30', 4, 'Manufacturing', 'Syria', 2574.00, 30888.00, 3.00, 3, 0, 4.00);
INSERT INTO public.employees VALUES (682, 'Diea', 'Shuelan', 'Male', '2019-03-06', 6, 'Manufacturing', 'Egypt', 1123.00, 13476.00, 1.00, 0, 0, 7.00);
INSERT INTO public.employees VALUES (683, 'Husam', 'Alsaed', 'Male', '2016-05-12', 9, 'Account Management', 'United Arab Emirates', 2147.00, 25764.00, 3.00, 0, 4, 2.00);
INSERT INTO public.employees VALUES (684, 'Asd', 'Bwfaeur', 'Male', '2017-06-27', 7, 'IT', 'Egypt', 2929.00, 35148.00, 4.50, 0, 0, 2.00);
INSERT INTO public.employees VALUES (685, 'Sari', 'Hanna', 'Male', '2020-05-26', 4, 'Marketing', 'Lebanon', 1452.00, 17424.00, 2.00, 0, 3, 1.00);
INSERT INTO public.employees VALUES (686, 'Eubayda', 'Kayd', 'Male', '2020-06-03', 4, 'Facilities/Engineering', 'Egypt', 3237.00, 38844.00, 3.00, 1, 0, 4.00);
INSERT INTO public.employees VALUES (687, 'Khalil', 'Alkalu', 'Male', '2017-07-11', 7, 'Facilities/Engineering', 'Egypt', 2819.00, 33828.00, 5.00, 0, 0, 0.00);
INSERT INTO public.employees VALUES (688, 'Muhamad', 'Shrbjy', 'Male', '2018-05-30', 6, 'Creative', 'Egypt', 2069.00, 24828.00, 3.00, 0, 0, 10.00);
INSERT INTO public.employees VALUES (1, 'Ghadir', 'Hmshw', 'Male', '2018-04-04', 7, 'Quality Control', 'Egypt', 1560.00, 18720.00, 3.00, 1, 0, 183.00);


--
-- TOC entry 4909 (class 0 OID 25354)
-- Dependencies: 218
-- Data for Name: tax_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tax_rates VALUES (1, 0.00, 3000000.00, 3.00);
INSERT INTO public.tax_rates VALUES (2, 3000001.00, 6000000.00, 6.00);


--
-- TOC entry 4912 (class 0 OID 25390)
-- Dependencies: 221
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 4920 (class 0 OID 0)
-- Dependencies: 217
-- Name: tax_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_rates_id_seq', 2, true);


--
-- TOC entry 4921 (class 0 OID 0)
-- Dependencies: 220
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, false);


--
-- TOC entry 4758 (class 2606 OID 25388)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 4756 (class 2606 OID 25359)
-- Name: tax_rates tax_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_rates
    ADD CONSTRAINT tax_rates_pkey PRIMARY KEY (id);


--
-- TOC entry 4760 (class 2606 OID 25399)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- TOC entry 4762 (class 2606 OID 25401)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


-- Completed on 2025-05-19 09:48:16

--
-- PostgreSQL database dump complete
--

