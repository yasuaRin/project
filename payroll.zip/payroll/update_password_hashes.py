from werkzeug.security import generate_password_hash
import psycopg2

def get_db_connection():
    return psycopg2.connect(
        dbname="payroll_db",
        user="postgres",
        password="admin",
        host="localhost"
    )

def update_all_passwords():
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT employee_id FROM employees")
    ids = [row[0] for row in cur.fetchall()]

    for eid in ids:
        default_password = "final_destination"
        password_hash = generate_password_hash(default_password)

        cur.execute("""
            UPDATE employees 
            SET password_hash = %s 
            WHERE employee_id = %s
        """, (password_hash, eid))

    conn.commit()
    conn.close()
    print("✅ Updated all employee password hashes with new secure values")

if __name__ == '__main__':
    update_all_passwords()
